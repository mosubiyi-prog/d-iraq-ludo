// DEDA_SOCIAL_STABLE_IDENTITY_100269
// DEDA_SOCIAL_SERVICE_TYPES_100269
import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_functions/cloud_functions.dart';

import 'deda_backend.dart';

// DEDA_INTAKADHA_POINT16_READONLY_SOCIAL_ALIAS_FALLBACK_DEFAULT_OFF
// Server route is NEVER a location-sharing authorization.
// The original personal DEDA ID remains the persisted friend/profile key.
class DedaPoint16SocialAliasCompat {
  static const bool enabled = bool.fromEnvironment(
    'DEDA_PREMIUM_ALIAS_ROUTING_LIVE',
    defaultValue: false,
  );

  static Future<String?> tryResolve(String input) async {
    if (!enabled) return null;
    final requester = FirebaseAuth.instance.currentUser?.uid;
    if (requester == null || requester.isEmpty) return null;
    if (!RegExp(r'^@DEDA-[A-Z0-9]{4,12}$').hasMatch(input)) return null;
    try {
      final value = await FirebaseFunctions.instance
          .httpsCallable('dedaPremiumResolveAlias')
          .call<Map<String, dynamic>>(<String, dynamic>{
        'identifier': input,
      });
      if (FirebaseAuth.instance.currentUser?.uid != requester) return null;
      final data = Map<String, dynamic>.from(value.data);
      final original = data['originalId'];
      if (original is! String ||
          !RegExp(r'^@DEDA-[A-Z0-9]{6}$').hasMatch(original)) return null;
      return original;
    } catch (_) {
      // Offline, undeployed or unverified => old ID lookup stays unchanged.
      return null;
    }
  }
}

class DedaSocialProfile {
  final String publicId;
  final String ownerUid;
  final String displayName;
  final int avatarStyle;
  final int frameStyle;
  final int backgroundStyle;
  final int level;
  final List<String> badges;

  const DedaSocialProfile({
    required this.publicId,
    required this.ownerUid,
    required this.displayName,
    required this.avatarStyle,
    required this.frameStyle,
    required this.backgroundStyle,
    required this.level,
    required this.badges,
  });

  factory DedaSocialProfile.fromMap(Map<String, dynamic> data) {
    final rawBadges = data['badges'];
    return DedaSocialProfile(
      publicId: (data['publicId'] ?? '').toString(),
      ownerUid: (data['ownerUid'] ?? '').toString(),
      displayName: (data['displayName'] ?? 'DEDA').toString(),
      avatarStyle:
          ((data['avatarStyle'] as num?)?.toInt() ?? 0).clamp(0, 8).toInt(),
      frameStyle:
          ((data['frameStyle'] as num?)?.toInt() ?? 0).clamp(0, 18).toInt(),
      backgroundStyle:
          ((data['backgroundStyle'] as num?)?.toInt() ?? 0).clamp(0, 8).toInt(),
      level: ((data['level'] as num?)?.toInt() ?? 1).clamp(1, 999).toInt(),
      badges: rawBadges is List
          ? rawBadges.map((value) => value.toString()).take(12).toList()
          : const <String>[],
    );
  }
}

class DedaFriendshipRecord {
  final String id;
  final List<String> members;
  final String requesterUid;
  final String recipientUid;
  final String requesterPublicId;
  final String recipientPublicId;
  final String requesterName;
  final String recipientName;
  final String status;

  const DedaFriendshipRecord({
    required this.id,
    required this.members,
    required this.requesterUid,
    required this.recipientUid,
    required this.requesterPublicId,
    required this.recipientPublicId,
    required this.requesterName,
    required this.recipientName,
    required this.status,
  });

  factory DedaFriendshipRecord.fromDoc(
    QueryDocumentSnapshot<Map<String, dynamic>> doc,
  ) {
    return DedaFriendshipRecord.fromMap(doc.id, doc.data());
  }

  factory DedaFriendshipRecord.fromMap(
    String id,
    Map<String, dynamic> data,
  ) {
    final rawMembers = data['members'];
    return DedaFriendshipRecord(
      id: id,
      members: rawMembers is List
          ? rawMembers.map((value) => value.toString()).toList()
          : const <String>[],
      requesterUid: (data['requesterUid'] ?? '').toString(),
      recipientUid: (data['recipientUid'] ?? '').toString(),
      requesterPublicId: (data['requesterPublicId'] ?? '').toString(),
      recipientPublicId: (data['recipientPublicId'] ?? '').toString(),
      requesterName: (data['requesterName'] ?? 'DEDA').toString(),
      recipientName: (data['recipientName'] ?? 'DEDA').toString(),
      status: (data['status'] ?? '').toString(),
    );
  }

  String otherUid(String myUid) =>
      requesterUid == myUid ? recipientUid : requesterUid;

  String otherPublicId(String myUid) =>
      requesterUid == myUid ? recipientPublicId : requesterPublicId;

  String otherName(String myUid) =>
      requesterUid == myUid ? recipientName : requesterName;
}

class DedaSocialSession {
  final String uid;
  final String publicId;
  final DedaSocialProfile profile;

  const DedaSocialSession({
    required this.uid,
    required this.publicId,
    required this.profile,
  });
}

class DedaSocialService {
  static FirebaseFirestore get _db => FirebaseFirestore.instance;

  static String normalizePublicId(String raw) {
    var value = raw.trim().toUpperCase().replaceAll(' ', '');
    if (value.isNotEmpty && !value.startsWith('@')) value = '@$value';
    return value;
  }

  static bool looksLikePersonalId(String value) =>
      RegExp(r'^@DEDA-[A-Z0-9]{4,12}$').hasMatch(normalizePublicId(value));

  static String _pairKey(String firstUid, String secondUid) {
    final values = <String>[firstUid, secondUid]..sort();
    return '${values[0]}__${values[1]}';
  }

  static Future<DedaSocialSession> ensurePersonalSession({
    required String name,
    required String phone,
    required String accountType,
    required bool hasApprovedPlace,
    required int avatarStyle,
    required int frameStyle,
    required int backgroundStyle,
    required int level,
    List<String> badges = const <String>[],
  }) async {
    final identity = await DedaBackend.ensureLocationShareIdentity(
      name: name,
      phone: phone,
      hasApprovedPlace: hasApprovedPlace,
      accountType: accountType,
    );
    final publicId = normalizePublicId(identity['personalId'] ?? '');
    if (publicId.isEmpty) throw StateError('social-personal-id-missing');

    final user = FirebaseAuth.instance.currentUser;
    if (user == null) throw StateError('social-session-missing');

    final profileRef = _db.collection('deda_social_profiles').doc(publicId);
    final existing = await profileRef.get();
    await profileRef.set(<String, dynamic>{
      'publicId': publicId,
      'ownerUid': user.uid,
      'displayName': name.trim().isEmpty ? 'DEDA' : name.trim(),
      'avatarStyle': avatarStyle.clamp(0, 8).toInt(),
      'frameStyle': frameStyle.clamp(0, 18).toInt(),
      'backgroundStyle': backgroundStyle.clamp(0, 8).toInt(),
      'level': level.clamp(1, 999).toInt(),
      'badges': badges.take(12).toList(),
      if (!existing.exists) 'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));

    return DedaSocialSession(
      // Friendship identity follows the stable personal DEDA ID, not the
      // renewable anonymous Firebase uid. This preserves relations if the
      // authenticated session is refreshed on the same DEDA account.
      uid: publicId,
      publicId: publicId,
      profile: DedaSocialProfile(
        publicId: publicId,
        ownerUid: user.uid,
        displayName: name.trim().isEmpty ? 'DEDA' : name.trim(),
        avatarStyle: avatarStyle.clamp(0, 8).toInt(),
        frameStyle: frameStyle.clamp(0, 18).toInt(),
        backgroundStyle: backgroundStyle.clamp(0, 8).toInt(),
        level: level.clamp(1, 999).toInt(),
        badges: badges.take(12).toList(),
      ),
    );
  }

  static Future<DedaSocialProfile?> findByPublicId(String raw) async {
    final requestedId = normalizePublicId(raw);
    if (!looksLikePersonalId(requestedId)) return null;

    var publicId = requestedId;
    var directory = await _db.collection('deda_share_ids').doc(publicId).get();
    var directoryData = directory.data();
    // Original registered ID always takes priority; do not override existing
    // location/share records. Server fallback returns ONLY the old canonical ID.
    if ((!directory.exists ||
            directoryData == null ||
            directoryData['active'] != true ||
            directoryData['kind'] != 'personal') &&
        DedaPoint16SocialAliasCompat.enabled) {
      final canonical =
          await DedaPoint16SocialAliasCompat.tryResolve(requestedId);
      if (canonical != null && canonical != requestedId) {
        publicId = canonical;
        directory = await _db.collection('deda_share_ids').doc(publicId).get();
        directoryData = directory.data();
      }
    }
    if (!directory.exists ||
        directoryData == null ||
        directoryData['active'] != true ||
        directoryData['kind'] != 'personal') {
      return null;
    }

    final profile =
        await _db.collection('deda_social_profiles').doc(publicId).get();
    final data = profile.data();
    if (data != null) return DedaSocialProfile.fromMap(data);

    return DedaSocialProfile(
      publicId: publicId,
      ownerUid: (directoryData['ownerUid'] ?? '').toString(),
      displayName: (directoryData['displayName'] ?? 'DEDA').toString(),
      avatarStyle: 0,
      frameStyle: 0,
      backgroundStyle: 0,
      level: 1,
      badges: const <String>[],
    );
  }

  // DEDA_SOCIAL_QUERY_FIX_100270
  // Use two explicit equality queries instead of one array query. Firestore
  // can now prove from the query itself that every returned relation belongs
  // to the current stable personal DEDA ID. This also makes sent and received
  // requests visible without depending on renewable Firebase UIDs.
  static Stream<List<DedaFriendshipRecord>> watchRelations(String uid) {
    if (uid.isEmpty) return Stream.value(const <DedaFriendshipRecord>[]);

    late final StreamController<List<DedaFriendshipRecord>> controller;
    StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? sentSub;
    StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? receivedSub;
    final sent = <String, DedaFriendshipRecord>{};
    final received = <String, DedaFriendshipRecord>{};

    void emit() {
      if (controller.isClosed) return;
      final merged = <String, DedaFriendshipRecord>{
        ...sent,
        ...received,
      }
          .values
          .where((item) =>
              item.requesterPublicId == uid || item.recipientPublicId == uid)
          .toList();
      merged.sort((a, b) => a.otherName(uid).compareTo(b.otherName(uid)));
      controller.add(merged);
    }

    void forwardError(Object error, StackTrace stack) {
      if (!controller.isClosed) controller.addError(error, stack);
    }

    controller = StreamController<List<DedaFriendshipRecord>>.broadcast(
      onListen: () {
        sentSub ??= _db
            .collection('deda_friendships')
            .where('requesterPublicId', isEqualTo: uid)
            .snapshots()
            .listen((snapshot) {
          sent
            ..clear()
            ..addEntries(snapshot.docs.map((doc) {
              final item = DedaFriendshipRecord.fromDoc(doc);
              return MapEntry(item.id, item);
            }));
          emit();
        }, onError: forwardError);

        receivedSub ??= _db
            .collection('deda_friendships')
            .where('recipientPublicId', isEqualTo: uid)
            .snapshots()
            .listen((snapshot) {
          received
            ..clear()
            ..addEntries(snapshot.docs.map((doc) {
              final item = DedaFriendshipRecord.fromDoc(doc);
              return MapEntry(item.id, item);
            }));
          emit();
        }, onError: forwardError);
      },
      onCancel: () async {
        await sentSub?.cancel();
        await receivedSub?.cancel();
        sentSub = null;
        receivedSub = null;
      },
    );
    return controller.stream;
  }

  static Future<String> sendFriendRequest({
    required DedaSocialSession sender,
    required DedaSocialProfile target,
  }) async {
    if (target.publicId.isEmpty) throw StateError('social-target-missing');
    if (target.publicId == sender.publicId) {
      throw StateError('social-self-request');
    }

    final pairKey = _pairKey(sender.publicId, target.publicId);
    final ref = _db.collection('deda_friendships').doc(pairKey);
    final existing = await ref.get();
    final existingData = existing.data();
    if (existingData != null) {
      final status = (existingData['status'] ?? '').toString();
      if (status == 'accepted') throw StateError('social-already-friends');
      if (status == 'pending') throw StateError('social-request-pending');
      if (status == 'rejected') {
        await ref.delete();
      }
    }

    await ref.set(<String, dynamic>{
      'pairKey': pairKey,
      // The legacy *Uid field names are kept for schema compatibility, but
      // their values are stable personal DEDA IDs in the social system.
      'members': <String>[sender.publicId, target.publicId],
      'requesterUid': sender.publicId,
      'recipientUid': target.publicId,
      'requesterPublicId': sender.publicId,
      'recipientPublicId': target.publicId,
      'requesterName': sender.profile.displayName,
      'recipientName': target.displayName,
      'status': 'pending',
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
    return pairKey;
  }

  static Future<String> _currentPersonalId() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) throw StateError('social-session-missing');
    final snapshot = await _db.collection('users').doc(user.uid).get();
    final data = snapshot.data();
    final id = normalizePublicId((data?['sharePersonalId'] ?? '').toString());
    if (id.isEmpty) throw StateError('social-personal-id-missing');
    return id;
  }

  static Future<void> respondToRequest({
    required String relationId,
    required bool accept,
  }) async {
    final currentId = await _currentPersonalId();
    final ref = _db.collection('deda_friendships').doc(relationId);
    final snapshot = await ref.get();
    final data = snapshot.data();
    if (data == null || data['recipientUid'] != currentId) {
      throw StateError('social-request-not-owned');
    }
    if (data['status'] != 'pending') {
      throw StateError('social-request-not-pending');
    }
    await ref.update(<String, dynamic>{
      'status': accept ? 'accepted' : 'rejected',
      'respondedAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  static Future<void> removeRelation(String relationId) async {
    final currentId = await _currentPersonalId();
    final ref = _db.collection('deda_friendships').doc(relationId);
    final snapshot = await ref.get();
    final data = snapshot.data();
    final members = data?['members'];
    if (members is! List || !members.contains(currentId)) {
      throw StateError('social-relation-not-owned');
    }
    await ref.delete();
  }

  static Future<DedaSocialProfile?> profileForFriend(
    DedaFriendshipRecord relation,
    String myUid,
  ) async {
    if (relation.status != 'accepted' || !relation.members.contains(myUid)) {
      return null;
    }
    return findByPublicId(relation.otherPublicId(myUid));
  }
}
