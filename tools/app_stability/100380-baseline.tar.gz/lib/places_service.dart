import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:latlong2/latlong.dart';

import 'deda_request_coalescer.dart';
import 'deda_public_provider_health.dart';

class PlaceInfo {
  final String name;
  final String type;
  final LatLng location;
  final String? address;
  final String? phone;
  final String? website;
  final String? openingHours;
  final bool isDedaRegistered;
  final bool isAvailableNow;
  final String publishedPlaceId;
  final String logoUrl;
  final int themeIndex;

  const PlaceInfo({
    required this.name,
    required this.type,
    required this.location,
    this.address,
    this.phone,
    this.website,
    this.openingHours,
    this.isDedaRegistered = false,
    this.isAvailableNow = false,
    this.publishedPlaceId = '',
    this.logoUrl = '',
    this.themeIndex = 4,
  });

  Map<String, dynamic> toJson() => <String, dynamic>{
        'name': name,
        'type': type,
        'lat': location.latitude,
        'lon': location.longitude,
        'address': address,
        'phone': phone,
        'website': website,
        'openingHours': openingHours,
        'isDedaRegistered': isDedaRegistered,
        'isAvailableNow': isAvailableNow,
        'publishedPlaceId': publishedPlaceId,
        'logoUrl': logoUrl,
        'themeIndex': themeIndex,
      };

  factory PlaceInfo.fromJson(Map<String, dynamic> json) {
    return PlaceInfo(
      name: (json['name'] ?? 'مكان').toString(),
      type: (json['type'] ?? 'مكان').toString(),
      location: LatLng(
        (json['lat'] as num).toDouble(),
        (json['lon'] as num).toDouble(),
      ),
      address: json['address']?.toString(),
      phone: json['phone']?.toString(),
      website: json['website']?.toString(),
      openingHours: json['openingHours']?.toString(),
      isDedaRegistered: json['isDedaRegistered'] == true,
      isAvailableNow: json['isAvailableNow'] == true,
      publishedPlaceId: (json['publishedPlaceId'] ?? '').toString(),
      logoUrl: (json['logoUrl'] ?? '').toString(),
      themeIndex: (json['themeIndex'] as num?)?.toInt() ?? 4,
    );
  }
}

class PlacesService {
  static const List<String> _overpassUrls = [
    'https://overpass-api.de/api/interpreter',
    'https://overpass.kumi.systems/api/interpreter',
    'https://overpass.private.coffee/api/interpreter',
  ];

  static const Duration _requestTimeout = Duration(seconds: 14);

  // Only named public POI endpoints: no location, query, user ID or URL
  // is retained by this monitor. No telemetry is uploaded.
  static final DedaPublicProviderHealth _publicHealth =
      DedaPublicProviderHealth(
    providers: const <String>{
      'nominatim',
      'overpass-1',
      'overpass-2',
      'overpass-3',
    },
  );

  /// Diagnostic counters, for future opt-in admin diagnostics UI only.
  /// Nothing is sent remotely or displayed to the user automatically.
  static Map<String, Map<String, Object>> get publicProviderDiagnostics =>
      _publicHealth.snapshot();

  // PUBLIC OSM/Nominatim/Overpass results only. Never cache live GPS,
  // route geometry, road hazards or DEDA registered place availability here.
  // Bounded in-memory, no timer/network background jobs and no persistence.
  static final DedaRequestCoalescer<List<PlaceInfo>> _publicSearchGate =
      DedaRequestCoalescer<List<PlaceInfo>>(
    ttl: const Duration(seconds: 45),
    maxEntries: 24,
  );

  Future<List<PlaceInfo>> _cachedPublicPlaces(
    String key,
    Future<List<PlaceInfo>> Function() fetch,
  ) async {
    final results = await _publicSearchGate.run(
      key,
      fetch,
      // Avoid keeping huge nation-wide search responses in phone memory.
      cacheWhen: (places) => places.isNotEmpty && places.length <= 100,
    );
    // Callers sort/filter returned lists; never let them mutate cached data.
    return List<PlaceInfo>.of(results);
  }

  String _filterForType(String type) {
    switch (type) {
      case 'مطعم':
      case 'مطاعم':
        return '["amenity"="restaurant"]';
      case 'فندق':
      case 'فنادق':
        return '["tourism"="hotel"]';
      case 'مول':
      case 'مولات':
        return '["shop"="mall"]';
      case 'محطة وقود':
      case 'محطات وقود':
        return '["amenity"="fuel"]';
      case 'صيدلية':
      case 'صيدليات':
        return '["amenity"="pharmacy"]';
      case 'موقف':
      case 'مواقف':
        return '["amenity"="parking"]';
      case 'حديقة':
      case 'حدائق':
        return '["leisure"="park"]';
      default:
        return '';
    }
  }

  Future<List<PlaceInfo>> getNearbyPlaces({
    required LatLng center,
    required String type,
    int radiusMeters = 3000,
  }) async {
    final filter = _filterForType(type);
    if (filter.isEmpty) return [];

    final query = '''
[out:json][timeout:14];
nwr(around:$radiusMeters,${center.latitude},${center.longitude})$filter;
out center tags;
''';

    final key = 'nearby|$type|$radiusMeters|'
        '${center.latitude.toStringAsFixed(5)}|'
        '${center.longitude.toStringAsFixed(5)}';
    return _cachedPublicPlaces(
      key,
      () => _requestPlaces(query: query, fallbackType: type),
    );
  }

  Future<List<PlaceInfo>> searchPlacesByName({
    required LatLng center,
    required String queryText,
    int radiusMeters = 25000,
  }) async {
    final text = queryText.trim();
    if (text.length < 2) return <PlaceInfo>[];
    // Existing name search is global across Iraq (center is not sent to its
    // public providers). Keep the response semantics and preserve radius in
    // the key for future locality-aware search upgrades.
    return _cachedPublicPlaces(
      'iraq-name|${text.toLowerCase()}|$radiusMeters',
      () => _searchPlacesByNameUncached(
        center: center,
        queryText: text,
        radiusMeters: radiusMeters,
      ),
    );
  }

  Future<List<PlaceInfo>> _searchPlacesByNameUncached({
    required LatLng center,
    required String queryText,
    int radiusMeters = 25000,
  }) async {
    final text = queryText.trim();
    if (text.length < 2) return [];

    try {
      final nominatimResults = await _publicHealth.guard(
        'nominatim',
        () => _searchIraqWithNominatim(text),
      );
      if (nominatimResults.isNotEmpty) return nominatimResults;
    } catch (_) {
      // Fall back to Overpass below when the name-search service is busy.
    }

    final escaped = _escapeOverpassRegex(text);
    final query = '''
[out:json][timeout:14];
area["ISO3166-1"="IQ"][admin_level=2]->.iraq;
(
  nwr(area.iraq)["name"~"$escaped",i];
  nwr(area.iraq)["name:ar"~"$escaped",i];
);
out center tags;
''';

    final results = await _requestPlaces(
      query: query,
      fallbackType: 'مكان',
    );

    final seen = <String>{};
    final unique = <PlaceInfo>[];
    for (final place in results) {
      final key = '${place.name.toLowerCase()}|'
          '${place.location.latitude.toStringAsFixed(5)}|'
          '${place.location.longitude.toStringAsFixed(5)}';
      if (seen.add(key)) unique.add(place);
    }
    return unique;
  }

  Future<List<PlaceInfo>> _searchIraqWithNominatim(String text) async {
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 8);
    try {
      final uri = Uri.https(
        'nominatim.openstreetmap.org',
        '/search',
        <String, String>{
          'format': 'jsonv2',
          'q': text,
          'countrycodes': 'iq',
          'limit': '50',
          'addressdetails': '1',
          'accept-language': 'ar',
        },
      );
      final request = await client.getUrl(uri);
      request.headers.set(HttpHeaders.acceptHeader, 'application/json');
      request.headers.set(HttpHeaders.userAgentHeader, 'DEDA/1.0 (Android)');
      final response = await request.close().timeout(_requestTimeout);
      final body = await response.transform(utf8.decoder).join();
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw HttpException('Nominatim error: ${response.statusCode}');
      }
      final decoded = jsonDecode(body);
      if (decoded is! List) return [];

      final places = <PlaceInfo>[];
      final seen = <String>{};
      for (final raw in decoded) {
        if (raw is! Map) continue;
        final item = Map<String, dynamic>.from(raw);
        final latitude = double.tryParse((item['lat'] ?? '').toString());
        final longitude = double.tryParse((item['lon'] ?? '').toString());
        if (latitude == null || longitude == null) continue;
        final displayName = (item['display_name'] ?? '').toString().trim();
        final shortName = (item['name'] ?? '').toString().trim();
        final name = shortName.isNotEmpty
            ? shortName
            : (displayName.split(',').first.trim());
        final key = '${name.toLowerCase()}|${latitude.toStringAsFixed(5)}|'
            '${longitude.toStringAsFixed(5)}';
        if (!seen.add(key)) continue;
        places.add(
          PlaceInfo(
            name: name.isEmpty ? text : name,
            type: _typeFromNominatim(item),
            location: LatLng(latitude, longitude),
            address: displayName,
          ),
        );
      }
      return places;
    } finally {
      client.close(force: true);
    }
  }

  String _typeFromNominatim(Map<String, dynamic> item) {
    final type = (item['type'] ?? '').toString();
    switch (type) {
      case 'restaurant':
        return 'مطعم';
      case 'hotel':
        return 'فندق';
      case 'mall':
        return 'مول';
      case 'fuel':
        return 'محطة وقود';
      case 'pharmacy':
        return 'صيدلية';
      case 'parking':
        return 'موقف';
      case 'park':
        return 'حديقة';
      case 'hospital':
        return 'مستشفى';
      default:
        return 'مكان';
    }
  }

  String _escapeOverpassRegex(String value) {
    final escaped = value.replaceAll('\\', '\\\\').replaceAll('"', '\\"');
    return escaped.replaceAllMapped(
      RegExp(r'([.^$*+?()\[\]{}|])'),
      (match) => '\\${match.group(0)}',
    );
  }

  Future<List<PlaceInfo>> _requestPlaces({
    required String query,
    required String fallbackType,
  }) async {
    Object? lastError;

    for (var index = 0; index < _overpassUrls.length; index++) {
      final endpoint = _overpassUrls[index];
      try {
        return await _publicHealth.guard(
          'overpass-${index + 1}',
          () => _fetchFromEndpoint(
            endpoint: endpoint,
            query: query,
            fallbackType: fallbackType,
          ).timeout(_requestTimeout),
        );
      } on TimeoutException {
        lastError = HttpException(
          'Overpass timeout after ${_requestTimeout.inSeconds}s ($endpoint)',
        );
      } on SocketException catch (error) {
        lastError = SocketException(
          '${error.message} ($endpoint)',
          osError: error.osError,
          address: error.address,
          port: error.port,
        );
      } on HttpException catch (error) {
        lastError = error;
      } on FormatException catch (error) {
        lastError = error;
      } catch (error) {
        lastError = error;
      }
    }

    if (lastError != null) throw lastError;
    return [];
  }

  Future<List<PlaceInfo>> _fetchFromEndpoint({
    required String endpoint,
    required String query,
    required String fallbackType,
  }) async {
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 8);

    try {
      final uri = Uri.parse(endpoint).replace(
        queryParameters: <String, String>{'data': query},
      );
      final request = await client.getUrl(uri);
      request.headers.set(HttpHeaders.acceptHeader, 'application/json');
      request.headers.set(HttpHeaders.userAgentHeader, 'DEDA/1.0 (Android)');

      final response = await request.close();
      final body = await response.transform(utf8.decoder).join();

      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw HttpException(
          'Overpass error: ${response.statusCode} ($endpoint)',
        );
      }

      final decoded = jsonDecode(body);
      if (decoded is! Map<String, dynamic>) {
        throw const FormatException('Overpass response is not a JSON object');
      }

      final elements = decoded['elements'];
      if (elements is! List) return [];

      final places = <PlaceInfo>[];
      for (final element in elements) {
        if (element is! Map) continue;
        final item = Map<String, dynamic>.from(element);
        final rawTags = item['tags'];
        final tags = rawTags is Map
            ? Map<String, dynamic>.from(rawTags)
            : <String, dynamic>{};

        final rawName = tags['name:ar'] ?? tags['name'] ?? fallbackType;
        final name = rawName.toString().trim();

        double? latitude;
        double? longitude;
        if (item['lat'] is num && item['lon'] is num) {
          latitude = (item['lat'] as num).toDouble();
          longitude = (item['lon'] as num).toDouble();
        } else if (item['center'] is Map) {
          final center = Map<String, dynamic>.from(item['center'] as Map);
          if (center['lat'] is num && center['lon'] is num) {
            latitude = (center['lat'] as num).toDouble();
            longitude = (center['lon'] as num).toDouble();
          }
        }
        if (latitude == null || longitude == null) continue;

        places.add(
          PlaceInfo(
            name: name.isEmpty ? fallbackType : name,
            type: _typeFromTags(tags, fallbackType),
            location: LatLng(latitude, longitude),
            address: _addressFromTags(tags),
            phone: _firstText(tags, const ['contact:phone', 'phone']),
            website: _firstText(tags, const ['contact:website', 'website']),
            openingHours: _firstText(tags, const ['opening_hours']),
          ),
        );
      }
      return places;
    } finally {
      client.close(force: true);
    }
  }

  String _typeFromTags(Map<String, dynamic> tags, String fallback) {
    final amenity = tags['amenity']?.toString();
    final tourism = tags['tourism']?.toString();
    final shop = tags['shop']?.toString();
    final leisure = tags['leisure']?.toString();

    switch (amenity) {
      case 'restaurant':
        return 'مطعم';
      case 'pharmacy':
        return 'صيدلية';
      case 'fuel':
        return 'محطة وقود';
      case 'parking':
        return 'موقف';
      case 'cafe':
        return 'مقهى';
      case 'hospital':
        return 'مستشفى';
      case 'school':
        return 'مدرسة';
      case 'bank':
        return 'مصرف';
    }
    if (tourism == 'hotel') return 'فندق';
    if (shop == 'mall') return 'مول';
    if (leisure == 'park') return 'حديقة';
    return fallback.isEmpty ? 'مكان' : fallback;
  }

  String? _addressFromTags(Map<String, dynamic> tags) {
    final direct = _firstText(tags, const ['addr:full']);
    if (direct != null) return direct;

    final parts = <String>[
      if ((tags['addr:street'] ?? '').toString().trim().isNotEmpty)
        tags['addr:street'].toString().trim(),
      if ((tags['addr:housenumber'] ?? '').toString().trim().isNotEmpty)
        tags['addr:housenumber'].toString().trim(),
      if ((tags['addr:city'] ?? '').toString().trim().isNotEmpty)
        tags['addr:city'].toString().trim(),
    ];
    return parts.isEmpty ? null : parts.join('، ');
  }

  String? _firstText(Map<String, dynamic> tags, List<String> keys) {
    for (final key in keys) {
      final value = tags[key]?.toString().trim();
      if (value != null && value.isNotEmpty) return value;
    }
    return null;
  }
}
