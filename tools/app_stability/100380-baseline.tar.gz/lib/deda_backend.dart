import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:firebase_storage/firebase_storage.dart';

import 'deda_pin_auth.dart';
import 'deda_qa32_public_recipient_resolver.dart';

class DedaBackend {
  static bool get isReady => Firebase.apps.isNotEmpty;

  // Keep the authenticated administrator profile warm for short navigation
  // hops. Firestore security rules remain authoritative for every write.
  static Map<String, dynamic>? _cachedAdminProfile;
  static String? _cachedAdminUid;
  static DateTime? _cachedAdminAt;
  static const Duration _adminProfileCacheTtl = Duration(seconds: 45);

  static void _clearAdminProfileCache() {
    _cachedAdminProfile = null;
    _cachedAdminUid = null;
    _cachedAdminAt = null;
  }

  // Build 87 review fixes: one logical account key per normalized phone.
  // Firebase anonymous UIDs may differ per device, so DEDA data also carries
  // this stable key. Phone verification can later harden ownership without
  // changing the stored account linkage.
  static String accountKeyForPhone(String phone) =>
      phone.replaceAll(RegExp(r'[^0-9]'), '');

  static String _adminEntryAccountKeyForPhone(String phone) {
    var digits = accountKeyForPhone(phone);
    if (digits.startsWith('00964')) {
      digits = digits.substring(2);
    } else if (digits.startsWith('07') && digits.length == 11) {
      digits = '964${digits.substring(1)}';
    } else if (digits.startsWith('7') && digits.length == 10) {
      digits = '964$digits';
    }

    final numeric = int.tryParse(digits);
    if (digits.length == 13 && digits.startsWith('9647') && numeric != null) {
      return digits;
    }
    return '';
  }

  static Future<String> _currentAccountKey(User user) async {
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .get();
      final key = (snapshot.data()?['accountKey'] ?? '').toString().trim();
      if (key.isNotEmpty) return key;
    } catch (_) {}
    return user.uid;
  }

  static Future<User> _ensurePublicUser() async {
    if (!isReady) throw StateError('firebase-not-ready');
    final auth = FirebaseAuth.instance;
    final currentUser = auth.currentUser;
    if (currentUser != null) return currentUser;
    final credential = await auth.signInAnonymously();
    if (credential.user == null) throw StateError('anonymous-auth-failed');
    return credential.user!;
  }

  static Future<User> _ensureOwnerSessionForAccountKey(
    String accountKey,
  ) async {
    final cleanKey = accountKey.trim();
    var user = await _ensurePublicUser();
    if (cleanKey.isEmpty) return user;

    // Reuse the current DEDA session when it is already the same owner.
    if (user.isAnonymous) {
      try {
        final session = await FirebaseFirestore.instance
            .collection('deda_sessions')
            .doc(user.uid)
            .get();
        if (session.exists &&
            (session.data()?['accountKey'] ?? '').toString() == cleanKey) {
          return user;
        }
      } catch (_) {}
    } else {
      // Admin sign-in uses the same FirebaseAuth instance. Leaving admin work
      // for owner work must close that admin session cleanly first.
      await signOutAdmin();
    }

    user = await DedaPinAuth.restoreTrustedSessionForAccountKey(cleanKey);
    return user;
  }

  static Future<bool> _isCurrentGeneralManagerSession(User user) async {
    if (user.isAnonymous) return false;
    try {
      final profile = await currentAdminProfile();
      return normalizeAdminRole(profile['role']) == 'general_manager';
    } catch (_) {
      return false;
    }
  }

  static String normalizeAdminRole(dynamic value) {
    final raw = (value ?? '').toString().trim().toLowerCase();
    if (raw.isEmpty ||
        raw == 'manager' ||
        raw == 'director' ||
        raw == 'admin' ||
        raw == 'general_manager') {
      return 'general_manager';
    }
    if (raw == 'assistant' ||
        raw == 'assistant_manager' ||
        raw == 'assistant-manager' ||
        raw == 'deputy_manager') {
      return 'deputy_manager';
    }
    if (raw == 'staff' || raw == 'employee') return 'employee';
    if (raw == 'agent' ||
        raw == 'governorate_agent' ||
        raw == 'province_agent') {
      return 'province_agent';
    }
    return raw;
  }

  static String normalizeAdminStatus(Map<String, dynamic>? data) {
    if (data == null) return 'disabled';
    final raw = (data['status'] ?? '').toString().trim().toLowerCase();
    if (raw == 'active' || raw == 'temporarily_stopped' || raw == 'disabled') {
      return raw;
    }
    return data['active'] == true ? 'active' : 'disabled';
  }

  static bool adminHasPermission(
    Map<String, dynamic>? profile,
    String permission,
  ) {
    if (profile == null) return false;
    final role = normalizeAdminRole(profile['role'] ?? profile['jobTitle']);
    if (role == 'general_manager') return true;
    final permissions = profile['permissions'];
    return permissions is Map && permissions[permission] == true;
  }

  static Future<Map<String, dynamic>> currentAdminProfile({
    bool forceRefresh = false,
  }) async {
    if (!isReady) throw StateError('firebase-not-ready');
    final user = FirebaseAuth.instance.currentUser;
    if (user == null || user.isAnonymous) {
      _clearAdminProfileCache();
      throw StateError('admin-not-signed-in');
    }

    final now = DateTime.now();
    final cached = _cachedAdminProfile;
    final cachedAt = _cachedAdminAt;
    if (!forceRefresh &&
        cached != null &&
        _cachedAdminUid == user.uid &&
        cachedAt != null &&
        now.difference(cachedAt) <= _adminProfileCacheTtl) {
      return Map<String, dynamic>.from(cached);
    }

    final ref = FirebaseFirestore.instance.collection('admins').doc(user.uid);
    final snapshot = await ref.get();
    final data = snapshot.data();
    if (!snapshot.exists ||
        data?['active'] != true ||
        normalizeAdminStatus(data) != 'active') {
      _clearAdminProfileCache();
      throw StateError('admin-not-authorized');
    }

    final role = normalizeAdminRole(data?['role'] ?? data?['jobTitle']);
    final profile = <String, dynamic>{
      ...?data,
      'uid': user.uid,
      'email': user.email ?? data?['email'] ?? '',
      'displayName':
          (data?['displayName'] ?? data?['name'] ?? user.email ?? 'DEDA Admin')
              .toString(),
      'role': role,
      'status': normalizeAdminStatus(data),
      'roleNormalized': role,
    };
    _cachedAdminProfile = Map<String, dynamic>.from(profile);
    _cachedAdminUid = user.uid;
    _cachedAdminAt = now;
    return Map<String, dynamic>.from(profile);
  }

  static Future<Map<String, String>> _adminIdentity() async {
    final data = await currentAdminProfile();
    return <String, String>{
      'uid': data['uid'].toString(),
      'name': data['displayName'].toString(),
      'role': normalizeAdminRole(data['role']),
    };
  }

  static Future<void> _writeAdminAudit(
    String action, {
    Map<String, dynamic> details = const <String, dynamic>{},
  }) async {
    try {
      final actor = await _adminIdentity();
      await FirebaseFirestore.instance.collection('admin_audit').add({
        'action': action,
        'adminUid': actor['uid'],
        'adminName': actor['name'],
        'adminRole': actor['role'],
        ...details,
        'createdAt': FieldValue.serverTimestamp(),
      });
    } catch (_) {}
  }

  // DEDA_ADMIN_DIAMONDS_100270
  static const int generalManagerDiamondGiftBudget = 1000000;

  static String _normalizePersonalDedaId(String raw) {
    var value = raw.trim().toUpperCase().replaceAll(' ', '');
    if (value.isNotEmpty && !value.startsWith('@')) value = '@$value';
    return value;
  }

  static bool _looksLikePersonalDedaId(String value) =>
      RegExp(r'^@DEDA-[A-Z0-9]{5,12}$')
          .hasMatch(_normalizePersonalDedaId(value));

  /// Creates the protected one-million administrative gift wallet once.
  /// It is available only to a currently authenticated active general manager.
  static Future<int> ensureGeneralManagerDiamondGiftWallet() async {
    if (!isReady) throw StateError('firebase-not-ready');
    final user = FirebaseAuth.instance.currentUser;
    if (user == null ||
        user.isAnonymous ||
        !await _isCurrentGeneralManagerSession(user)) {
      throw StateError('general-manager-required');
    }

    final ref = FirebaseFirestore.instance
        .collection('deda_admin_diamond_wallets')
        .doc(user.uid);
    return FirebaseFirestore.instance.runTransaction<int>((transaction) async {
      final snapshot = await transaction.get(ref);
      if (!snapshot.exists) {
        transaction.set(ref, <String, dynamic>{
          'adminUid': user.uid,
          'initialBalance': generalManagerDiamondGiftBudget,
          'balance': generalManagerDiamondGiftBudget,
          'createdAt': FieldValue.serverTimestamp(),
          'updatedAt': FieldValue.serverTimestamp(),
        });
        return generalManagerDiamondGiftBudget;
      }
      final balance = ((snapshot.data()?['balance'] as num?)?.toInt() ?? 0)
          .clamp(0, generalManagerDiamondGiftBudget)
          .toInt();
      return balance;
    });
  }

  static Future<Map<String, dynamic>?> adminDiamondGiftTarget(
    String rawPublicId,
  ) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null ||
        user.isAnonymous ||
        !await _isCurrentGeneralManagerSession(user)) {
      throw StateError('general-manager-required');
    }
    final publicId = _normalizePersonalDedaId(rawPublicId);
    if (!_looksLikePersonalDedaId(publicId)) return null;
    final snapshot = await FirebaseFirestore.instance
        .collection('deda_share_ids')
        .doc(publicId)
        .get();
    final data = snapshot.data();
    if (!snapshot.exists ||
        data == null ||
        data['active'] != true ||
        data['kind'] != 'personal') {
      return null;
    }
    // Read only public display fields. No phone, email, ownerUid, or PIN
    // leaves this function. An optional public profile must NOT block
    // legitimate gifting if the social profile does not exist yet.
    Map<String, dynamic>? social;
    try {
      final socialDoc = await FirebaseFirestore.instance
          .collection('deda_social_profiles')
          .doc(publicId)
          .get();
      social = socialDoc.data();
    } catch (_) {
      social = null;
    }
    final publicName = (social?['displayName'] ?? data['displayName'] ?? 'DEDA')
        .toString()
        .trim();
    return <String, dynamic>{
      'publicId': publicId,
      'displayName': publicName.isEmpty ? 'DEDA' : publicName,
      'avatarStyle': social?['avatarStyle'],
      'frameStyle': social?['frameStyle'],
      'backgroundStyle': social?['backgroundStyle'],
      'level': social?['level'],
    };
  }

  /// Atomically deducts the manager pool, credits the user's remote gift
  /// balance and writes an immutable audit gift record.
  // DEDA_GIFTS_BACKEND_100271
  /// Atomically deducts the protected administrative pool and creates a
  /// PENDING gift. The recipient balance is intentionally untouched here.
  static Future<Map<String, dynamic>> grantDiamondGift({
    required String targetPublicId,
    required int amount,
    required String reason,
  }) async {
    if (amount <= 0 || amount > generalManagerDiamondGiftBudget) {
      throw ArgumentError('invalid-diamond-gift-amount');
    }
    final cleanReason = reason.trim();
    if (cleanReason.isEmpty || cleanReason.length > 220) {
      throw ArgumentError('invalid-diamond-gift-reason');
    }
    final user = FirebaseAuth.instance.currentUser;
    if (user == null ||
        user.isAnonymous ||
        !await _isCurrentGeneralManagerSession(user)) {
      throw StateError('general-manager-required');
    }
    final admin = await currentAdminProfile(forceRefresh: true);
    final target = await adminDiamondGiftTarget(targetPublicId);
    if (target == null) throw StateError('diamond-gift-target-not-found');
    final publicId = target['publicId'].toString();
    final targetName = target['displayName'].toString();

    await ensureGeneralManagerDiamondGiftWallet();

    final firestore = FirebaseFirestore.instance;
    final walletRef =
        firestore.collection('deda_admin_diamond_wallets').doc(user.uid);
    final giftRef = firestore.collection('deda_diamond_gifts').doc();

    final result = await firestore.runTransaction<Map<String, dynamic>>(
      (transaction) async {
        final walletSnapshot = await transaction.get(walletRef);
        if (!walletSnapshot.exists) {
          throw StateError('diamond-admin-wallet-missing');
        }
        final currentAdmin =
            ((walletSnapshot.data()?['balance'] as num?)?.toInt() ?? 0)
                .clamp(0, generalManagerDiamondGiftBudget)
                .toInt();
        if (currentAdmin < amount) {
          throw StateError('diamond-admin-balance-insufficient');
        }
        final nextAdmin = currentAdmin - amount;

        // DEDA_GIFT_WALLET_DEBIT_PROOF_2026_10_10
        // Immutable pending-gift ID proves this debit is paired with
        // exactly one gift creation in the SAME Firestore transaction.
        transaction.update(walletRef, <String, dynamic>{
          'balance': nextAdmin,
          'lastGiftId': giftRef.id,
          'updatedAt': FieldValue.serverTimestamp(),
        });
        transaction.set(giftRef, <String, dynamic>{
          'giftId': giftRef.id,
          'sourceType': 'admin',
          'adminUid': user.uid,
          'adminName': (admin['displayName'] ?? 'DEDA Admin').toString(),
          'senderLabel': 'إدارة DEDA',
          'targetPublicId': publicId,
          'targetName': targetName,
          'amount': amount,
          'reason': cleanReason,
          'status': 'pending',
          'createdAt': FieldValue.serverTimestamp(),
        });
        return <String, dynamic>{
          'giftId': giftRef.id,
          'targetPublicId': publicId,
          'targetName': targetName,
          'amount': amount,
          'reason': cleanReason,
          'status': 'pending',
          'adminBalance': nextAdmin,
        };
      },
    );

    // The gift entry is already durably committed and visible in manager
    // history. Do not report 'send failed' when optional secondary audit is
    // interrupted after the gift was actually created.
    try {
      await _writeAdminAudit(
        'diamond_gift_created',
        details: <String, dynamic>{
          'giftId': result['giftId'],
          'targetPublicId': publicId,
          'targetName': targetName,
          'amount': amount,
          'reason': cleanReason,
          'status': 'pending',
          'adminBalanceAfter': result['adminBalance'],
        },
      );
    } catch (_) {
      // Core atomic gift creation remains valid in deda_diamond_gifts.
    }
    return result;
  }

  static List<Map<String, dynamic>> _sortedGiftMaps(
    QuerySnapshot<Map<String, dynamic>> snapshot,
  ) {
    final items = snapshot.docs
        .map((doc) => <String, dynamic>{...doc.data(), 'giftId': doc.id})
        .toList();
    items.sort((a, b) {
      final av = a['createdAt'];
      final bv = b['createdAt'];
      final am = av is Timestamp ? av.toDate().millisecondsSinceEpoch : 0;
      final bm = bv is Timestamp ? bv.toDate().millisecondsSinceEpoch : 0;
      return bm.compareTo(am);
    });
    return items;
  }

  static Stream<List<Map<String, dynamic>>> watchPersonalDiamondGifts(
    String rawPublicId,
  ) {
    final publicId = _normalizePersonalDedaId(rawPublicId);
    if (!_looksLikePersonalDedaId(publicId)) {
      return Stream<List<Map<String, dynamic>>>.value(
        const <Map<String, dynamic>>[],
      );
    }
    return FirebaseFirestore.instance
        .collection('deda_diamond_gifts')
        .where('targetPublicId', isEqualTo: publicId)
        .snapshots()
        .map(_sortedGiftMaps);
  }

  static Stream<List<Map<String, dynamic>>> watchCurrentAdminDiamondGifts() {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null || user.isAnonymous) {
      return Stream<List<Map<String, dynamic>>>.value(
        const <Map<String, dynamic>>[],
      );
    }
    return FirebaseFirestore.instance
        .collection('deda_diamond_gifts')
        .where('adminUid', isEqualTo: user.uid)
        .snapshots()
        .map(_sortedGiftMaps);
  }

  /// Claims exactly one pending gift. The gift state transition and the remote
  /// spendable balance increase are committed in the SAME transaction.
  static Future<Map<String, dynamic>> claimDiamondGift({
    required String giftId,
    required String targetPublicId,
  }) async {
    final cleanGiftId = giftId.trim();
    final publicId = _normalizePersonalDedaId(targetPublicId);
    if (cleanGiftId.isEmpty || !_looksLikePersonalDedaId(publicId)) {
      throw ArgumentError('invalid-diamond-gift-claim');
    }
    final firestore = FirebaseFirestore.instance;
    final giftRef = firestore.collection('deda_diamond_gifts').doc(cleanGiftId);
    final balanceRef =
        firestore.collection('deda_diamond_gift_balances').doc(publicId);

    final result = await firestore.runTransaction<Map<String, dynamic>>(
      (transaction) async {
        final giftSnapshot = await transaction.get(giftRef);
        if (!giftSnapshot.exists || giftSnapshot.data() == null) {
          throw StateError('diamond-gift-not-found');
        }
        final gift = giftSnapshot.data()!;
        if ((gift['targetPublicId'] ?? '').toString() != publicId) {
          throw StateError('diamond-gift-not-owner');
        }
        if ((gift['status'] ?? '').toString() != 'pending') {
          throw StateError('diamond-gift-already-claimed');
        }
        final amount = ((gift['amount'] as num?)?.toInt() ?? 0);
        if (amount <= 0) throw StateError('diamond-gift-invalid-amount');

        final balanceSnapshot = await transaction.get(balanceRef);
        final current = balanceSnapshot.exists
            ? ((balanceSnapshot.data()?['balance'] as num?)?.toInt() ?? 0)
                .clamp(0, 1 << 30)
                .toInt()
            : 0;
        final next = current + amount;

        if (balanceSnapshot.exists) {
          transaction.update(balanceRef, <String, dynamic>{
            'balance': next,
            'lastClaimGiftId': cleanGiftId,
            'updatedAt': FieldValue.serverTimestamp(),
          });
        } else {
          transaction.set(balanceRef, <String, dynamic>{
            'publicId': publicId,
            'balance': next,
            'lastClaimGiftId': cleanGiftId,
            'createdAt': FieldValue.serverTimestamp(),
            'updatedAt': FieldValue.serverTimestamp(),
          });
        }
        transaction.update(giftRef, <String, dynamic>{
          'status': 'received',
          'claimedAt': FieldValue.serverTimestamp(),
        });
        return <String, dynamic>{
          'giftId': cleanGiftId,
          'amount': amount,
          'balance': next,
          'status': 'received',
        };
      },
    );
    return result;
  }

  /// Reads the server-backed gift portion of a personal diamond balance.
  static Future<int> personalGiftedDiamondBalance(String rawPublicId) async {
    final publicId = _normalizePersonalDedaId(rawPublicId);
    if (!_looksLikePersonalDedaId(publicId)) return 0;
    final snapshot = await FirebaseFirestore.instance
        .collection('deda_diamond_gift_balances')
        .doc(publicId)
        .get();
    return ((snapshot.data()?['balance'] as num?)?.toInt() ?? 0)
        .clamp(0, 1 << 30)
        .toInt();
  }

  /// The personal account may only DECREASE its own remote gift balance.
  /// Firestore rules reject any attempt by a normal user to increase it.
  static Future<int> spendPersonalGiftedDiamonds({
    required String publicId,
    required int amount,
  }) async {
    if (amount <= 0) return personalGiftedDiamondBalance(publicId);
    final normalized = _normalizePersonalDedaId(publicId);
    if (!_looksLikePersonalDedaId(normalized)) {
      throw StateError('diamond-gift-personal-id-missing');
    }
    final ref = FirebaseFirestore.instance
        .collection('deda_diamond_gift_balances')
        .doc(normalized);
    return FirebaseFirestore.instance.runTransaction<int>((transaction) async {
      final snapshot = await transaction.get(ref);
      final current = ((snapshot.data()?['balance'] as num?)?.toInt() ?? 0)
          .clamp(0, 1 << 30)
          .toInt();
      if (current < amount) {
        throw StateError('diamond-gift-balance-insufficient');
      }
      final next = current - amount;
      transaction.update(ref, <String, dynamic>{
        'balance': next,
        'updatedAt': FieldValue.serverTimestamp(),
      });
      return next;
    });
  }

  /// Personal testing diamonds for an authorized general-manager gateway
  /// account. This wallet is separate from the administrative gift pool.
  /// Unauthorized personal accounts receive null and are not modified.
  static Future<int?> ensureGeneralManagerPersonalDiamondWallet({
    required String phone,
  }) async {
    if (!isReady) return null;
    final accountKey = accountKeyForPhone(phone).trim();
    final user = FirebaseAuth.instance.currentUser;
    if (accountKey.isEmpty || user == null || !user.isAnonymous) return null;
    final ref = FirebaseFirestore.instance
        .collection('deda_gm_personal_diamond_wallets')
        .doc(accountKey);
    try {
      return await FirebaseFirestore.instance.runTransaction<int>(
        (transaction) async {
          final snapshot = await transaction.get(ref);
          if (snapshot.exists) {
            return ((snapshot.data()?['balance'] as num?)?.toInt() ?? 0)
                .clamp(0, generalManagerDiamondGiftBudget)
                .toInt();
          }
          transaction.set(ref, <String, dynamic>{
            'accountKey': accountKey,
            'initialBalance': generalManagerDiamondGiftBudget,
            'balance': generalManagerDiamondGiftBudget,
            'createdAt': FieldValue.serverTimestamp(),
            'updatedAt': FieldValue.serverTimestamp(),
          });
          return generalManagerDiamondGiftBudget;
        },
      );
    } on FirebaseException catch (error) {
      if (error.code == 'permission-denied') return null;
      rethrow;
    }
  }

  static Future<int> spendGeneralManagerPersonalDiamonds({
    required String phone,
    required int amount,
  }) async {
    if (amount <= 0) return 0;
    final accountKey = accountKeyForPhone(phone).trim();
    if (accountKey.isEmpty) throw StateError('gm-personal-account-missing');
    final ref = FirebaseFirestore.instance
        .collection('deda_gm_personal_diamond_wallets')
        .doc(accountKey);
    return FirebaseFirestore.instance.runTransaction<int>((transaction) async {
      final snapshot = await transaction.get(ref);
      if (!snapshot.exists) throw StateError('gm-personal-wallet-missing');
      final current = ((snapshot.data()?['balance'] as num?)?.toInt() ?? 0)
          .clamp(0, generalManagerDiamondGiftBudget)
          .toInt();
      if (current < amount)
        throw StateError('gm-personal-balance-insufficient');
      final next = current - amount;
      transaction.update(ref, <String, dynamic>{
        'balance': next,
        'updatedAt': FieldValue.serverTimestamp(),
      });
      return next;
    });
  }

  static bool _hasRequiredPlaceData(Map<String, dynamic> data) {
    const requiredTextFields = [
      'placeName',
      'phone',
      'governorate',
      'address',
      'openingHours',
      'description',
    ];
    final hasText = requiredTextFields.every(
      (key) => data[key]?.toString().trim().isNotEmpty == true,
    );
    final hasLocation = data['latitude'] is num && data['longitude'] is num;
    final hasCategory = data['category']?.toString().trim().isNotEmpty == true;
    final hasCustomType = data['category'] != 'other' ||
        data['otherCategoryText']?.toString().trim().isNotEmpty == true;
    return hasText && hasLocation && hasCategory && hasCustomType;
  }

  // DEDA 10-point fixes v1: unified user identity + robust support uploads.
  static Future<void> syncCurrentUserProfile({
    required String name,
    required String phone,
    required String accountType,
  }) async {
    final user = await _ensurePublicUser();
    final ref = FirebaseFirestore.instance.collection('users').doc(user.uid);
    final existing = await ref.get();
    await ref.set({
      'name': name.trim(),
      'phone': phone.trim(),
      'accountKey': accountKeyForPhone(phone),
      'accountType': accountType.trim(),
      if (!existing.exists) 'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
      'lastSeenAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  static Future<bool> _hasActivePlaceRequest(
    String ownerUid,
    String accountKey,
  ) async {
    final firestore = FirebaseFirestore.instance;
    try {
      final byAccount = await firestore
          .collection('place_requests')
          .where('accountKey', isEqualTo: accountKey)
          .limit(25)
          .get();
      if (byAccount.docs.any((doc) {
        final status = (doc.data()['status'] ?? '').toString();
        return status == 'pending' || status == 'reviewing';
      })) return true;
    } catch (_) {}

    final byUid = await firestore
        .collection('place_requests')
        .where('ownerUid', isEqualTo: ownerUid)
        .limit(25)
        .get();
    return byUid.docs.any((doc) {
      final status = (doc.data()['status'] ?? '').toString();
      return status == 'pending' || status == 'reviewing';
    });
  }

  static Future<String> submitSupport({
    required String type,
    required String name,
    required String phone,
    required String message,
    List<String> imagePaths = const <String>[],
  }) async {
    if (imagePaths.length > 1) {
      throw ArgumentError('support-image-limit');
    }

    final user = await _ensurePublicUser();
    final firestore = FirebaseFirestore.instance;
    final request = firestore.collection('support_requests').doc();
    final cleanName = name.trim();
    final cleanPhone = phone.trim();
    final accountKey = accountKeyForPhone(cleanPhone);

    // Best effort only: a stale deployed users rule must never block a support
    // message or photo. Login/profile sync can retry independently.
    try {
      await firestore.collection('users').doc(user.uid).set({
        'name': cleanName,
        'phone': cleanPhone,
        'accountKey': accountKey,
        'updatedAt': FieldValue.serverTimestamp(),
        'lastSeenAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    } catch (_) {}

    final cleanImagePaths = imagePaths
        .map((path) => path.trim())
        .where((path) => path.isNotEmpty)
        .take(1)
        .toList();

    final imageUrls = <String>[];
    final imageMimeTypes = <String>[];
    final uploadedReferences = <Reference>[];
    String? legacyImageBase64;
    String? legacyImageMimeType;

    try {
      for (var index = 0; index < cleanImagePaths.length; index++) {
        final imagePath = cleanImagePaths[index];
        final file = File(imagePath);
        if (!await file.exists()) throw StateError('support-image-missing');
        final bytes = await file.readAsBytes();
        if (bytes.length > 8 * 1024 * 1024) {
          throw StateError('support-image-too-large');
        }

        final extension = imagePath.contains('.')
            ? imagePath.split('.').last.toLowerCase()
            : 'jpg';
        final contentType = switch (extension) {
          'png' => 'image/png',
          'webp' => 'image/webp',
          'gif' => 'image/gif',
          _ => 'image/jpeg',
        };

        try {
          final reference = FirebaseStorage.instance.ref(
            'support_uploads/${user.uid}/${request.id}_${index + 1}.$extension',
          );
          await reference.putData(
            bytes,
            SettableMetadata(contentType: contentType),
          );
          uploadedReferences.add(reference);
          imageUrls.add(await reference.getDownloadURL());
          imageMimeTypes.add(contentType);
        } catch (_) {
          // Keep the proven single-photo Firestore fallback while Storage is
          // unavailable. The release UI intentionally permits one photo only.
          if (cleanImagePaths.length == 1 && bytes.length <= 650 * 1024) {
            legacyImageBase64 = base64Encode(bytes);
            legacyImageMimeType = contentType;
          } else {
            rethrow;
          }
        }
      }

      // If this is a place owner, link the support ticket directly to the
      // approved DEDA place so the employee never has to search for it manually.
      Map<String, dynamic>? linkedPlace;
      String? linkedPlaceId;
      try {
        final owned = await firestore
            .collection('published_places')
            .where('ownerUid', isEqualTo: user.uid)
            .limit(20)
            .get();
        for (final doc in owned.docs) {
          if (doc.data()['published'] == true) {
            linkedPlaceId = doc.id;
            linkedPlace = doc.data();
            break;
          }
        }
      } catch (_) {}

      final firstImageUrl = imageUrls.isEmpty ? null : imageUrls.first;
      final firstMimeType =
          imageMimeTypes.isEmpty ? legacyImageMimeType : imageMimeTypes.first;

      await request.set({
        'ownerUid': user.uid,
        'accountKey': accountKey,
        'type': type,
        'name': cleanName,
        'phone': cleanPhone,
        'message': message.trim(),
        // New multi-photo fields. Legacy fields remain for old builds/data.
        'imageUrls': imageUrls,
        'imageMimeTypes': imageMimeTypes,
        'imageUrl': firstImageUrl,
        'imageBase64': legacyImageBase64,
        'imageMimeType': firstMimeType,
        'status': 'new',
        if (linkedPlaceId != null) 'linkedPlaceId': linkedPlaceId,
        if (linkedPlace != null) ...{
          'linkedPlaceName': linkedPlace['placeName'],
          'linkedApprovalNumber': linkedPlace['approvalNumber'],
          'linkedLatitude': linkedPlace['latitude'],
          'linkedLongitude': linkedPlace['longitude'],
          'linkedSourceRequestId': linkedPlace['lastSourceRequestId'] ??
              linkedPlace['sourceRequestId'],
        },
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
      return request.id;
    } catch (_) {
      // Avoid orphaned Storage objects if a multi-photo request fails midway.
      for (final reference in uploadedReferences) {
        try {
          await reference.delete();
        } catch (_) {}
      }
      rethrow;
    }
  }

  static Future<String> submitPlace(Map<String, dynamic> data) async {
    if (!_hasRequiredPlaceData(data)) {
      throw ArgumentError('incomplete-place-request');
    }
    final user = await _ensurePublicUser();
    final accountKey = await _currentAccountKey(user);
    if (await _hasActivePlaceRequest(user.uid, accountKey)) {
      throw StateError('active-place-request');
    }
    await registerOwnerNotifications();
    final request =
        FirebaseFirestore.instance.collection('place_requests').doc();
    await request.set({
      ...data,
      'ownerUid': user.uid,
      'accountKey': accountKey,
      'requestType': 'create',
      'status': 'pending',
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
    return request.id;
  }

  static Future<String> submitPlaceEdit({
    required String originalPlaceId,
    required Map<String, dynamic> data,
  }) async {
    if (!_hasRequiredPlaceData(data)) {
      throw ArgumentError('incomplete-place-request');
    }
    final user = await _ensurePublicUser();
    final accountKey = await _currentAccountKey(user);
    if (await _hasActivePlaceRequest(user.uid, accountKey)) {
      throw StateError('active-place-request');
    }
    await registerOwnerNotifications();
    final original = await FirebaseFirestore.instance
        .collection('published_places')
        .doc(originalPlaceId)
        .get();
    final originalData = original.data();
    final sameOwner = originalData?['ownerUid'] == user.uid ||
        (originalData?['accountKey']?.toString() == accountKey);
    if (!original.exists || !sameOwner) {
      throw StateError('not-place-owner');
    }
    final request =
        FirebaseFirestore.instance.collection('place_requests').doc();
    await request.set({
      ...data,
      'ownerUid': user.uid,
      'accountKey': accountKey,
      'requestType': 'update',
      'originalPlaceId': originalPlaceId,
      'status': 'pending',
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
    return request.id;
  }

  static Future<String> resubmitPlaceRequest({
    required String requestId,
    required Map<String, dynamic> data,
  }) async {
    if (!_hasRequiredPlaceData(data)) {
      throw ArgumentError('incomplete-place-request');
    }
    final cleanId = requestId.trim();
    if (cleanId.isEmpty) throw ArgumentError('place-request-id-required');

    final firestore = FirebaseFirestore.instance;
    var user = await _ensurePublicUser();
    var accountKey = await _currentAccountKey(user);
    final request = firestore.collection('place_requests').doc(cleanId);
    final snapshot = await request.get();
    final existing = snapshot.data();
    if (!snapshot.exists || existing == null) {
      throw StateError('place-request-not-found');
    }

    final requestAccountKey = (existing['accountKey'] ?? '').toString().trim();
    if (requestAccountKey.isNotEmpty && requestAccountKey != accountKey) {
      user = await _ensureOwnerSessionForAccountKey(requestAccountKey);
      accountKey = await _currentAccountKey(user);
    }

    final sameOwner = existing['ownerUid'] == user.uid ||
        (requestAccountKey.isNotEmpty && requestAccountKey == accountKey);
    if (!sameOwner) throw StateError('not-place-owner');
    if ((existing['status'] ?? '').toString() != 'needs_changes') {
      throw StateError('place-request-not-awaiting-owner-changes');
    }

    await registerOwnerNotifications();
    await request.update(<String, dynamic>{
      ...data,
      'status': 'pending',
      'updatedAt': FieldValue.serverTimestamp(),
      'resubmittedAt': FieldValue.serverTimestamp(),
    });
    return cleanId;
  }

  static Future<Map<String, dynamic>?> ownerRequestById(String id) async {
    final user = await _ensurePublicUser();
    final accountKey = await _currentAccountKey(user);
    final snapshot = await FirebaseFirestore.instance
        .collection('place_requests')
        .doc(id)
        .get();
    final data = snapshot.data();
    if (!snapshot.exists || data == null) return null;
    final sameOwner = data['ownerUid'] == user.uid ||
        data['accountKey']?.toString() == accountKey;
    if (!sameOwner) return null;
    return {'id': snapshot.id, ...data};
  }

  static Future<Map<String, dynamic>?> publishedPlaceById(String id) async {
    if (!isReady) return null;
    final snapshot = await FirebaseFirestore.instance
        .collection('published_places')
        .doc(id)
        .get();
    final data = snapshot.data();
    if (!snapshot.exists || data == null) return null;
    return {'id': snapshot.id, ...data};
  }

  static Future<void> registerOwnerNotifications() async {
    final user = await _ensurePublicUser();
    await FirebaseMessaging.instance.requestPermission();
    final token = await FirebaseMessaging.instance.getToken();
    if (token == null || token.isEmpty) return;
    await FirebaseFirestore.instance.collection('users').doc(user.uid).set({
      'fcmTokens': FieldValue.arrayUnion([token]),
      'lastSeenAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  static const Set<String> _ownerNotificationTypes = <String>{
    'deletion_approved',
    'deletion_rejected',
    'needs_changes',
    'edit_approved',
    'place_report',
    'admin_alert',
    'custom',
  };

  static Map<String, dynamic> _ownerNotificationPayload({
    required Map<String, dynamic> actor,
    required String type,
    required String accountKey,
    required String ownerUid,
    required String placeId,
    required String placeName,
    required String approvalNumber,
    required String governorate,
    required String titleAr,
    required String titleEn,
    required String bodyAr,
    required String bodyEn,
    required String sourceType,
    required String sourceId,
  }) {
    if (!_ownerNotificationTypes.contains(type)) {
      throw ArgumentError('invalid-owner-notification-type');
    }
    return <String, dynamic>{
      'type': type,
      'accountKey': accountKey.trim(),
      'ownerUid': ownerUid.trim(),
      'placeId': placeId.trim(),
      'placeName': placeName.trim(),
      'approvalNumber': approvalNumber.trim(),
      'governorate': governorate.trim(),
      'titleAr': titleAr.trim(),
      'titleEn': titleEn.trim(),
      'bodyAr': bodyAr.trim(),
      'bodyEn': bodyEn.trim(),
      'sourceType': sourceType.trim(),
      'sourceId': sourceId.trim(),
      'createdByUid': (actor['uid'] ?? '').toString(),
      'createdByName': (actor['displayName'] ?? actor['name'] ?? '').toString(),
      'createdByRole': normalizeAdminRole(actor['role']),
      'createdAt': FieldValue.serverTimestamp(),
    };
  }

  static Stream<List<Map<String, dynamic>>> ownerPlaceNotificationsStream(
    String accountKey,
  ) {
    final clean = accountKey.trim();
    if (clean.isEmpty) {
      return Stream<List<Map<String, dynamic>>>.value(
        const <Map<String, dynamic>>[],
      );
    }
    return FirebaseFirestore.instance
        .collection('owner_place_notifications')
        .where('accountKey', isEqualTo: clean)
        .limit(100)
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map((doc) => <String, dynamic>{'id': doc.id, ...doc.data()})
              .toList(),
        );
  }

  static Future<List<Map<String, dynamic>>> ownerPlaceNotifications(
    String accountKey,
  ) async {
    final clean = accountKey.trim();
    if (clean.isEmpty) return const <Map<String, dynamic>>[];
    await _ensureOwnerSessionForAccountKey(clean);
    final snapshot = await FirebaseFirestore.instance
        .collection('owner_place_notifications')
        .where('accountKey', isEqualTo: clean)
        .limit(100)
        .get();
    return snapshot.docs
        .map((doc) => <String, dynamic>{'id': doc.id, ...doc.data()})
        .toList();
  }

  static Future<void> markOwnerPlaceNotificationsRead({
    required String accountKey,
    required List<String> notificationIds,
  }) async {
    final cleanAccountKey = accountKey.trim();
    final ids = notificationIds
        .map((id) => id.trim())
        .where((id) => id.isNotEmpty)
        .take(100)
        .toList();
    if (cleanAccountKey.isEmpty || ids.isEmpty) return;

    // Reading an owner notification is an owner-account action. DEDA admin
    // authentication shares FirebaseAuth with the public app, so always
    // restore/verify the stable phone-account session before writing readAt.
    await _ensureOwnerSessionForAccountKey(cleanAccountKey);

    final firestore = FirebaseFirestore.instance;
    final batch = firestore.batch();
    for (final id in ids) {
      batch.update(
        firestore.collection('owner_place_notifications').doc(id),
        <String, dynamic>{'readAt': FieldValue.serverTimestamp()},
      );
    }
    await batch.commit();
  }

  static Future<void> _writeOwnerNotificationAudit({
    required String notificationType,
    required String sourceType,
    required String sourceId,
    required String placeId,
    required String placeName,
    required String accountKey,
    required String titleAr,
    required String bodyAr,
  }) async {
    await _writeAdminAudit(
      'owner_notification_sent',
      details: <String, dynamic>{
        'notificationType': notificationType,
        'sourceType': sourceType,
        'sourceId': sourceId,
        'placeId': placeId,
        'placeName': placeName,
        'accountKey': accountKey,
        'title': titleAr,
        'message': bodyAr,
      },
    );
  }

  static Future<void> sendOwnerPlaceNotificationFromAdmin({
    required String sourceCollection,
    required String sourceId,
    required String type,
    required String titleAr,
    required String titleEn,
    required String bodyAr,
    required String bodyEn,
  }) async {
    if (!<String>{'published_places', 'place_requests'}
        .contains(sourceCollection)) {
      throw ArgumentError('invalid-owner-notification-source');
    }
    if (!<String>{'place_report', 'admin_alert', 'custom'}.contains(type)) {
      throw ArgumentError('invalid-manual-owner-notification-type');
    }
    if (titleAr.trim().isEmpty ||
        titleEn.trim().isEmpty ||
        bodyAr.trim().isEmpty ||
        bodyEn.trim().isEmpty) {
      throw ArgumentError('owner-notification-text-required');
    }

    final actor = await currentAdminProfile();
    final firestore = FirebaseFirestore.instance;
    final sourceRef = firestore.collection(sourceCollection).doc(sourceId);
    final sourceSnapshot = await sourceRef.get();
    final data = sourceSnapshot.data();
    if (!sourceSnapshot.exists || data == null) {
      throw StateError('owner-notification-source-not-found');
    }

    final accountKey = (data['accountKey'] ?? '').toString().trim();
    if (accountKey.isEmpty) {
      throw StateError('owner-account-not-linked');
    }
    final ownerUid = (data['ownerUid'] ?? '').toString().trim();
    final originalPlaceId = (data['originalPlaceId'] ?? '').toString().trim();
    final placeId = sourceCollection == 'published_places'
        ? sourceId
        : (originalPlaceId.isNotEmpty ? originalPlaceId : sourceId);
    final placeName =
        (data['placeName'] ?? data['name'] ?? '').toString().trim();
    final approvalNumber = (data['approvalNumber'] ?? '').toString().trim();
    final governorate = (data['governorate'] ?? '').toString().trim();

    final notification =
        firestore.collection('owner_place_notifications').doc();
    await notification.set(
      _ownerNotificationPayload(
        actor: actor,
        type: type,
        accountKey: accountKey,
        ownerUid: ownerUid,
        placeId: placeId,
        placeName: placeName,
        approvalNumber: approvalNumber,
        governorate: governorate,
        titleAr: titleAr,
        titleEn: titleEn,
        bodyAr: bodyAr,
        bodyEn: bodyEn,
        sourceType: sourceCollection,
        sourceId: sourceId,
      ),
    );

    await _writeOwnerNotificationAudit(
      notificationType: type,
      sourceType: sourceCollection,
      sourceId: sourceId,
      placeId: placeId,
      placeName: placeName,
      accountKey: accountKey,
      titleAr: titleAr,
      bodyAr: bodyAr,
    );
  }

  static Future<void> updateOwnerAvailability({
    required String placeId,
    required bool isAvailableNow,
  }) async {
    await _ensurePublicUser();
    await FirebaseFirestore.instance
        .collection('published_places')
        .doc(placeId)
        .update({
      'isAvailableNow': isAvailableNow,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  static Future<Map<String, dynamic>?> ownerPlaceDeletionRequestForPlace(
    String placeId, {
    String? accountKeyOverride,
  }) async {
    final cleanId = placeId.trim();
    if (cleanId.isEmpty) return null;

    final firestore = FirebaseFirestore.instance;
    final override = accountKeyOverride?.trim() ?? '';
    var user = await _ensurePublicUser();
    final generalManagerSession = await _isCurrentGeneralManagerSession(user);

    // The caller on "Manage my place" always knows the currently signed-in
    // DEDA account key. Prefer that key before touching published_places.
    // After an approved deletion the published document no longer exists and
    // must not be required just to read the preserved deletion-request record.
    var accountKey = override;

    if (!generalManagerSession && accountKey.isNotEmpty) {
      user = await _ensureOwnerSessionForAccountKey(accountKey);
    }

    // Legacy callers may not supply an account key. In that case, only use
    // the still-published place as a fallback to recover its owner linkage.
    if (!generalManagerSession && accountKey.isEmpty) {
      String placeOwnerUid = '';
      String placeAccountKey = '';
      try {
        final placeSnapshot =
            await firestore.collection('published_places').doc(cleanId).get();
        final place = placeSnapshot.data();
        placeOwnerUid = (place?['ownerUid'] ?? '').toString().trim();
        placeAccountKey = (place?['accountKey'] ?? '').toString().trim();
      } catch (_) {}

      accountKey = placeAccountKey.isNotEmpty
          ? placeAccountKey
          : await _currentAccountKey(user);
      if (placeOwnerUid != user.uid && accountKey.isNotEmpty) {
        user = await _ensureOwnerSessionForAccountKey(accountKey);
      }
    }

    final snapshot = await firestore
        .collection('place_deletion_requests')
        .doc(cleanId)
        .get();
    final data = snapshot.data();
    if (!snapshot.exists || data == null) return null;
    if (generalManagerSession) {
      return <String, dynamic>{'id': snapshot.id, ...data};
    }

    final sameOwner = data['requesterUid'] == user.uid ||
        (accountKey.isNotEmpty &&
            data['accountKey']?.toString().trim() == accountKey);
    if (!sameOwner) return null;
    return <String, dynamic>{'id': snapshot.id, ...data};
  }

  static Future<String> submitPlaceDeletionRequest({
    required String placeId,
    String reason = '',
    String? accountKeyOverride,
  }) async {
    final cleanId = placeId.trim();
    if (cleanId.isEmpty) throw ArgumentError('place-id-required');

    final firestore = FirebaseFirestore.instance;
    var user = await _ensurePublicUser();
    final generalManagerSession = await _isCurrentGeneralManagerSession(user);

    // Read the approved place before changing authentication state. DEDA's
    // general manager may use the same phone for both owner testing and
    // administration; older approved places can predate PIN trusted-device
    // migration. Keeping the authorized manager session avoids breaking that
    // legitimate test path while ordinary users still require owner proof.
    final placeRef = firestore.collection('published_places').doc(cleanId);
    final placeSnapshot = await placeRef.get();
    final place = placeSnapshot.data();
    if (!placeSnapshot.exists || place == null) {
      throw StateError('published-place-not-found');
    }

    final placeOwnerUid = (place['ownerUid'] ?? '').toString().trim();
    final placeAccountKey = (place['accountKey'] ?? '').toString().trim();
    final override = accountKeyOverride?.trim() ?? '';
    var accountKey = placeAccountKey.isNotEmpty
        ? placeAccountKey
        : (override.isNotEmpty ? override : await _currentAccountKey(user));

    if (!generalManagerSession && placeOwnerUid != user.uid) {
      if (placeAccountKey.isEmpty) {
        throw StateError('not-place-owner');
      }
      user = await _ensureOwnerSessionForAccountKey(placeAccountKey);
      accountKey = placeAccountKey;
    }

    final sameOwner = generalManagerSession ||
        placeOwnerUid == user.uid ||
        (placeAccountKey.isNotEmpty && placeAccountKey == accountKey);
    if (!sameOwner) throw StateError('not-place-owner');

    final requestRef =
        firestore.collection('place_deletion_requests').doc(cleanId);
    final existing = await requestRef.get();
    if (existing.exists && existing.data() != null) {
      final status = (existing.data()!['status'] ?? '').toString();
      if (status == 'new' || status == 'reviewing') {
        return requestRef.id;
      }
      if (status == 'deleted') {
        throw StateError('place-already-deleted');
      }
      if (status == 'rejected' ||
          status == 'cancelled' ||
          status == 'pending') {
        await requestRef.update(<String, dynamic>{
          'status': 'new',
          'reason': reason.trim(),
          'updatedAt': FieldValue.serverTimestamp(),
          'resubmittedAt': FieldValue.serverTimestamp(),
        });
        return requestRef.id;
      }
    }

    await requestRef.set(<String, dynamic>{
      'requesterUid': user.uid,
      'accountKey': accountKey,
      'placeId': cleanId,
      'placeName': (place['placeName'] ?? place['name'] ?? '').toString(),
      'approvalNumber': (place['approvalNumber'] ?? '').toString(),
      'governorate': (place['governorate'] ?? '').toString(),
      'address': (place['address'] ?? '').toString(),
      'phone': (place['phone'] ?? '').toString(),
      if (place['latitude'] is num) 'latitude': place['latitude'],
      if (place['longitude'] is num) 'longitude': place['longitude'],
      'reason': reason.trim(),
      'status': 'new',
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
    return requestRef.id;
  }

  static int _hazardLifetimeHours(String type) {
    switch (type) {
      case 'congestion':
        return 1;
      case 'accident':
      case 'road_object':
        return 2;
      case 'checkpoint':
        return 4;
      case 'flooded':
        return 6;
      case 'detour':
      case 'roadworks':
      case 'maintenance':
        return 12;
      case 'bump':
      case 'speed_camera':
        return 24 * 30;
      default:
        return 6;
    }
  }

  static const Set<String> _hazardTypes = <String>{
    'bump',
    'roadworks',
    'maintenance',
    'detour',
    'speed_camera',
    'checkpoint',
    'accident',
    'congestion',
    'road_object',
    'flooded',
  };

  static Future<List<Map<String, dynamic>>> roadHazards() async {
    if (!isReady) return const <Map<String, dynamic>>[];
    await _ensurePublicUser();
    final snapshot = await FirebaseFirestore.instance
        .collection('road_hazards')
        .where('status', isEqualTo: 'active')
        .limit(500)
        .get();
    final now = DateTime.now().millisecondsSinceEpoch;
    final items = <Map<String, dynamic>>[];
    for (final doc in snapshot.docs) {
      final data = doc.data();
      final expiresAt = data['expiresAt'];
      final expiresMillis =
          expiresAt is Timestamp ? expiresAt.millisecondsSinceEpoch : 0;
      final resolved = (data['resolvedReports'] as num?)?.toInt() ?? 0;
      if (expiresMillis > 0 && expiresMillis <= now) continue;
      if (resolved >= 3) continue;
      items.add(<String, dynamic>{
        'id': doc.id,
        ...data,
        'expiresAtMillis': expiresMillis,
      });
    }
    return items;
  }

  static Future<String> submitRoadHazard({
    required String type,
    required double latitude,
    required double longitude,
    double? heading,
  }) async {
    if (!_hazardTypes.contains(type)) {
      throw ArgumentError('invalid-road-hazard-type');
    }
    if (latitude < -90 ||
        latitude > 90 ||
        longitude < -180 ||
        longitude > 180) {
      throw ArgumentError('invalid-road-hazard-location');
    }

    final user = await _ensurePublicUser();
    final expires =
        DateTime.now().add(Duration(hours: _hazardLifetimeHours(type)));
    final ref = FirebaseFirestore.instance.collection('road_hazards').doc();
    await ref.set(<String, dynamic>{
      'reporterUid': user.uid,
      'type': type,
      'latitude': latitude,
      'longitude': longitude,
      'heading': heading,
      'status': 'active',
      'confirmations': 1,
      'resolvedReports': 0,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
      'lastConfirmedAt': FieldValue.serverTimestamp(),
      'expiresAt': Timestamp.fromDate(expires),
    });
    return ref.id;
  }

  static Future<void> voteRoadHazard({
    required String id,
    required String type,
    required bool present,
  }) async {
    if (!_hazardTypes.contains(type)) {
      throw ArgumentError('invalid-road-hazard-type');
    }
    await _ensurePublicUser();
    final ref = FirebaseFirestore.instance.collection('road_hazards').doc(id);
    if (present) {
      final expires =
          DateTime.now().add(Duration(hours: _hazardLifetimeHours(type)));
      await ref.update(<String, dynamic>{
        'confirmations': FieldValue.increment(1),
        'lastConfirmedAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
        'expiresAt': Timestamp.fromDate(expires),
      });
    } else {
      await ref.update(<String, dynamic>{
        'resolvedReports': FieldValue.increment(1),
        'updatedAt': FieldValue.serverTimestamp(),
      });
    }
  }

  static Future<bool> signInAdmin({
    required String email,
    required String password,
    String displayName = '',
  }) async {
    if (!isReady) throw StateError('firebase-not-ready');
    _clearAdminProfileCache();
    final credential = await FirebaseAuth.instance.signInWithEmailAndPassword(
      email: email.trim(),
      password: password,
    );
    final uid = credential.user?.uid;
    if (uid == null) return false;
    final admin =
        await FirebaseFirestore.instance.collection('admins').doc(uid).get();
    final data = admin.data();
    if (admin.exists) {
      final status = normalizeAdminStatus(data);
      if (data?['active'] != true || status != 'active') {
        await FirebaseAuth.instance.signOut();
        if (status == 'temporarily_stopped') {
          throw StateError('admin-temporarily-stopped');
        }
        throw StateError('admin-disabled');
      }

      final cleanName = displayName.trim();
      final update = <String, dynamic>{
        'lastSeenAt': FieldValue.serverTimestamp(),
        'lastLoginAt': FieldValue.serverTimestamp(),
      };
      if (cleanName.isNotEmpty) {
        update.addAll(<String, dynamic>{
          'displayName': cleanName,
          'updatedAt': FieldValue.serverTimestamp(),
        });
      }
      await FirebaseFirestore.instance
          .collection('admins')
          .doc(uid)
          .set(update, SetOptions(merge: true));
      // Notification registration is secondary. A temporary FCM / Play
      // Services failure must never turn a valid admin authentication into a
      // false "sign-in failed" result.
      try {
        await registerAdminNotifications();
      } catch (_) {}
      await _writeAdminAudit('admin_signed_in');
      return true;
    }
    await FirebaseAuth.instance.signOut();
    return false;
  }

  static Future<void> updateCurrentAdminDisplayName(
    String displayName,
  ) async {
    if (!isReady) throw StateError('firebase-not-ready');
    final user = FirebaseAuth.instance.currentUser;
    if (user == null || user.isAnonymous) {
      throw StateError('admin-not-signed-in');
    }

    final cleanName = displayName.trim();
    if (cleanName.length < 2) {
      throw ArgumentError('invalid-admin-display-name');
    }

    final ref = FirebaseFirestore.instance.collection('admins').doc(user.uid);
    final snapshot = await ref.get();
    final data = snapshot.data();
    if (!snapshot.exists ||
        data?['active'] != true ||
        normalizeAdminStatus(data) != 'active') {
      throw StateError('admin-not-authorized');
    }

    await ref.set({
      'displayName': cleanName,
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
    _clearAdminProfileCache();

    await _writeAdminAudit(
      'admin_display_name_updated',
      details: <String, dynamic>{
        'targetAdminName': cleanName,
      },
    );
  }

  static Future<bool> currentUserIsAdmin() async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (!isReady ||
        uid == null ||
        FirebaseAuth.instance.currentUser!.isAnonymous) {
      return false;
    }
    final admin =
        await FirebaseFirestore.instance.collection('admins').doc(uid).get();
    final data = admin.data();
    return admin.exists &&
        data?['active'] == true &&
        normalizeAdminStatus(data) == 'active';
  }

  // Administration entry visibility is separate from admin authentication.
  // The current DEDA account must be explicitly authorized in the protected
  // admin_entry_access registry. A live admin session never auto-grants a
  // phone number; general-manager gateway phones are added deliberately.
  static bool _adminEntryAccessVisible(Map<String, dynamic>? data) {
    if (data == null ||
        data['active'] != true ||
        (data['status'] ?? '').toString().trim().toLowerCase().isEmpty) {
      return false;
    }
    final status = (data['status'] ?? '').toString().trim().toLowerCase();
    if (status == 'active') return true;
    if (status != 'invited') return false;
    final expiresAt = data['expiresAt'];
    return expiresAt is Timestamp && expiresAt.toDate().isAfter(DateTime.now());
  }

  static String adminEntryPhoneDisplay(String value) {
    final key = _adminEntryAccountKeyForPhone(value);
    if (key.startsWith('9647') && key.length == 13) {
      return '0${key.substring(3)}';
    }
    return value.trim();
  }

  // Invited non-general-manager accounts keep a one-to-one DEDA-phone binding.
  // General-manager gateway phones are never created here automatically.
  static Future<void> syncCurrentAdminEntryAccessForDedaAccount({
    required String phone,
  }) async {
    if (!isReady) return;
    final accountKey = _adminEntryAccountKeyForPhone(phone);
    if (accountKey.isEmpty) return;

    final profile = await currentAdminProfile(forceRefresh: true);
    final status = normalizeAdminStatus(profile);
    if (profile['active'] != true || status != 'active') return;

    final role = normalizeAdminRole(profile['role']);
    if (role == 'general_manager') return;

    final profilePhoneKey =
        _adminEntryAccountKeyForPhone((profile['phone'] ?? '').toString());
    if (profilePhoneKey != accountKey) return;

    final ref = FirebaseFirestore.instance
        .collection('admin_entry_access')
        .doc(accountKey);
    final snapshot = await ref.get();
    final data = snapshot.data();
    if (!snapshot.exists || data == null) return;

    final allowedEmail = (data['allowedAdminEmail'] ?? data['email'] ?? '')
        .toString()
        .trim()
        .toLowerCase();
    final profileEmail =
        (profile['email'] ?? '').toString().trim().toLowerCase();
    final allowedRole = normalizeAdminRole(
      data['allowedRole'] ?? data['role'],
    );
    if (allowedEmail.isEmpty ||
        allowedEmail != profileEmail ||
        allowedRole != role) {
      return;
    }

    await ref.update(<String, dynamic>{
      'accessType': 'member',
      'allowedRole': role,
      'allowedAdminEmail': profileEmail,
      'adminUid': profile['uid'].toString(),
      'adminId': (profile['adminId'] ?? '').toString(),
      'status': 'active',
      'active': true,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  static Future<bool> currentDedaAccountCanSeeAdminEntry({
    required String phone,
  }) async {
    if (!isReady) return false;
    final accountKey = _adminEntryAccountKeyForPhone(phone);
    if (accountKey.isEmpty) return false;

    try {
      final authUser = FirebaseAuth.instance.currentUser;
      if (authUser == null || authUser.isAnonymous) {
        // Restore only the already trusted DEDA account session. Firestore
        // rules then allow this account to read its own gateway document.
        await DedaPinAuth.restoreTrustedSessionForAccountKey(accountKey);
      } else if (!await currentUserIsAdmin()) {
        // Never replace or sign out a non-anonymous non-admin session merely
        // to decide whether an administration UI element should be visible.
        return false;
      }

      final access = await FirebaseFirestore.instance
          .collection('admin_entry_access')
          .doc(accountKey)
          .get();
      final data = access.data();
      return access.exists &&
          data?['accountKey'] == accountKey &&
          _adminEntryAccessVisible(data);
    } catch (_) {
      // Fail closed: no authorization means no heading, card, button or gap.
      return false;
    }
  }

  /// Returns true only when the current DEDA phone is explicitly tied to
  /// an active general-manager gateway/member record. This intentionally
  /// fails closed; profile names or local UI state never grant the privilege.
  static Future<bool> currentDedaAccountIsGeneralManager({
    required String phone,
  }) async {
    if (!isReady) return false;
    final accountKey = _adminEntryAccountKeyForPhone(phone);
    if (accountKey.isEmpty) return false;

    try {
      final authUser = FirebaseAuth.instance.currentUser;
      if (authUser == null || authUser.isAnonymous) {
        await DedaPinAuth.restoreTrustedSessionForAccountKey(accountKey);
      } else if (!await currentUserIsAdmin()) {
        return false;
      }

      final access = await FirebaseFirestore.instance
          .collection('admin_entry_access')
          .doc(accountKey)
          .get();
      final data = access.data();
      if (!access.exists ||
          data == null ||
          data['accountKey'] != accountKey ||
          !_adminEntryAccessVisible(data)) {
        return false;
      }

      final accessType =
          (data['accessType'] ?? '').toString().trim().toLowerCase();
      final allowedRole = normalizeAdminRole(
        data['allowedRole'] ?? data['role'],
      );
      return accessType == 'general_manager_gateway' ||
          allowedRole == 'general_manager';
    } catch (_) {
      return false;
    }
  }

  // After an admin signs in, verify that the DEDA phone which opened the
  // gateway is allowed to use this specific admin identity.
  static Future<bool> currentAdminSessionMatchesDedaEntry({
    required String phone,
  }) async {
    if (!isReady) return false;
    final accountKey = _adminEntryAccountKeyForPhone(phone);
    if (accountKey.isEmpty) return false;

    try {
      final profile = await currentAdminProfile(forceRefresh: true);
      final access = await FirebaseFirestore.instance
          .collection('admin_entry_access')
          .doc(accountKey)
          .get();
      final data = access.data();
      if (!access.exists ||
          data == null ||
          data['accountKey'] != accountKey ||
          !_adminEntryAccessVisible(data)) {
        return false;
      }

      final role = normalizeAdminRole(profile['role']);
      final accessType =
          (data['accessType'] ?? '').toString().trim().toLowerCase();
      if (accessType == 'general_manager_gateway') {
        return role == 'general_manager' &&
            (data['allowedRole'] ?? 'general_manager').toString() ==
                'general_manager';
      }

      final allowedUid = (data['adminUid'] ?? '').toString().trim();
      final allowedEmail = (data['allowedAdminEmail'] ?? data['email'] ?? '')
          .toString()
          .trim()
          .toLowerCase();
      final profileEmail =
          (profile['email'] ?? '').toString().trim().toLowerCase();
      final allowedRole =
          normalizeAdminRole(data['allowedRole'] ?? data['role']);

      if (allowedRole != role) return false;

      final profileUid = profile['uid'].toString();
      final uidMatches = allowedUid.isNotEmpty && allowedUid == profileUid;
      final emailMatches =
          allowedEmail.isNotEmpty && allowedEmail == profileEmail;

      // Email is a stable Firebase Auth identity while a UID can become stale
      // after an administrative account is recreated. Accept either identity
      // only after the active admin profile and role already matched above.
      if (!uidMatches && !emailMatches) return false;

      // Best-effort self-heal for an older member gateway whose UID predates
      // the current Firebase Auth account. Security rules still decide whether
      // this repair is allowed; failure here must not block a valid login.
      if (!uidMatches && emailMatches && accessType == 'member') {
        try {
          await FirebaseFirestore.instance
              .collection('admin_entry_access')
              .doc(accountKey)
              .update(<String, dynamic>{
            'adminUid': profileUid,
            'adminId': (profile['adminId'] ?? '').toString(),
            'status': 'active',
            'active': true,
            'updatedAt': FieldValue.serverTimestamp(),
          });
        } catch (_) {}
      }
      return true;
    } catch (_) {
      return false;
    }
  }

  static Stream<QuerySnapshot<Map<String, dynamic>>>
      generalManagerAdminEntryPhones() {
    return FirebaseFirestore.instance
        .collection('admin_entry_access')
        .where('accessType', isEqualTo: 'general_manager_gateway')
        .snapshots();
  }

  static Future<void> addGeneralManagerAdminEntryPhone({
    required String phone,
  }) async {
    final actor = await currentAdminProfile(forceRefresh: true);
    if (normalizeAdminRole(actor['role']) != 'general_manager') {
      throw StateError('general-manager-required');
    }

    final accountKey = _adminEntryAccountKeyForPhone(phone);
    if (accountKey.isEmpty) {
      throw ArgumentError('invalid-deda-phone');
    }

    final directory = await FirebaseFirestore.instance
        .collection('deda_account_directory')
        .doc(accountKey)
        .get();
    if (!directory.exists || directory.data()?['active'] != true) {
      throw StateError('deda-account-not-found');
    }

    final ref = FirebaseFirestore.instance
        .collection('admin_entry_access')
        .doc(accountKey);
    final existing = await ref.get();
    final existingData = existing.data();
    if (existing.exists &&
        (existingData?['accessType'] ?? '').toString() !=
            'general_manager_gateway') {
      throw StateError('admin-entry-phone-already-assigned');
    }

    await ref.set(<String, dynamic>{
      'accountKey': accountKey,
      'phone': adminEntryPhoneDisplay(accountKey),
      'accessType': 'general_manager_gateway',
      'allowedRole': 'general_manager',
      'status': 'active',
      'active': true,
      if (!existing.exists) 'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
      'managedByUid': actor['uid'].toString(),
      'managedByName': actor['displayName'].toString(),
    }, SetOptions(merge: true));

    await _writeAdminAudit(
      'general_manager_entry_phone_added',
      details: <String, dynamic>{
        'targetAccountKey': accountKey,
      },
    );
  }

  static Future<void> removeGeneralManagerAdminEntryPhone({
    required String phoneOrAccountKey,
  }) async {
    final actor = await currentAdminProfile(forceRefresh: true);
    if (normalizeAdminRole(actor['role']) != 'general_manager') {
      throw StateError('general-manager-required');
    }

    final accountKey = _adminEntryAccountKeyForPhone(phoneOrAccountKey);
    if (accountKey.isEmpty) throw ArgumentError('invalid-deda-phone');

    final collection =
        FirebaseFirestore.instance.collection('admin_entry_access');
    final ref = collection.doc(accountKey);
    final snapshot = await ref.get();
    final data = snapshot.data();
    if (!snapshot.exists ||
        data == null ||
        (data['accessType'] ?? '').toString() != 'general_manager_gateway') {
      throw StateError('admin-entry-phone-not-found');
    }

    final gateways = await collection
        .where('accessType', isEqualTo: 'general_manager_gateway')
        .get();
    final activeCount =
        gateways.docs.where((doc) => doc.data()['active'] == true).length;
    if (data['active'] == true && activeCount <= 1) {
      throw StateError('last-general-manager-entry-phone');
    }

    await ref.delete();
    await _writeAdminAudit(
      'general_manager_entry_phone_removed',
      details: <String, dynamic>{
        'targetAccountKey': accountKey,
      },
    );
  }

  static Future<void> registerAdminNotifications() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null || user.isAnonymous) return;
    await FirebaseMessaging.instance.requestPermission();
    final token = await FirebaseMessaging.instance.getToken();
    if (token == null) return;
    await FirebaseFirestore.instance.collection('admins').doc(user.uid).set({
      'fcmTokens': FieldValue.arrayUnion([token]),
      'lastSeenAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  static Stream<QuerySnapshot<Map<String, dynamic>>> supportRequests() {
    return FirebaseFirestore.instance
        .collection('support_requests')
        .orderBy('createdAt', descending: true)
        .limit(100)
        .snapshots();
  }

  static Stream<QuerySnapshot<Map<String, dynamic>>> placeRequests() {
    return FirebaseFirestore.instance
        .collection('place_requests')
        .orderBy('createdAt', descending: true)
        .limit(100)
        .snapshots();
  }

  static Timestamp? _adminVisibilityCutoff(
    Map<String, dynamic> adminProfile,
  ) {
    final role = normalizeAdminRole(
      adminProfile['roleNormalized'] ?? adminProfile['role'],
    );
    if (role == 'general_manager') return null;

    final firstLogin = adminProfile['firstLoginCompletedAt'];
    if (firstLogin is Timestamp) return firstLogin;

    final createdAt = adminProfile['createdAt'];
    if (createdAt is Timestamp) return createdAt;

    // Fail closed for a non-general-manager account with incomplete metadata.
    return Timestamp.fromDate(DateTime.now().add(const Duration(days: 36500)));
  }

  static Stream<QuerySnapshot<Map<String, dynamic>>> placeRequestsForAdmin(
    Map<String, dynamic> adminProfile,
  ) {
    final role = normalizeAdminRole(
      adminProfile['roleNormalized'] ?? adminProfile['role'],
    );
    final cutoff = _adminVisibilityCutoff(adminProfile);
    final collection = FirebaseFirestore.instance.collection('place_requests');

    if (role == 'province_agent') {
      final governorate = (adminProfile['governorate'] ?? '').toString().trim();
      if (governorate.isEmpty) {
        return collection
            .where('governorate', isEqualTo: '__no_governorate__')
            .limit(1)
            .snapshots();
      }

      // Province scope is enforced server-side without a composite index.
      // The shared request-list UI applies the activation-time cutoff again
      // before counters or records are rendered.
      return collection
          .where('governorate', isEqualTo: governorate)
          .limit(100)
          .snapshots();
    }

    Query<Map<String, dynamic>> query = collection;
    if (cutoff != null) {
      query = query.where(
        'createdAt',
        isGreaterThanOrEqualTo: cutoff,
      );
    }
    return query.orderBy('createdAt', descending: true).limit(100).snapshots();
  }

  static Stream<QuerySnapshot<Map<String, dynamic>>> supportRequestsForAdmin(
    Map<String, dynamic> adminProfile,
  ) {
    final cutoff = _adminVisibilityCutoff(adminProfile);
    Query<Map<String, dynamic>> query =
        FirebaseFirestore.instance.collection('support_requests');
    if (cutoff != null) {
      query = query.where(
        'createdAt',
        isGreaterThanOrEqualTo: cutoff,
      );
    }
    return query.orderBy('createdAt', descending: true).limit(100).snapshots();
  }

  static Future<List<Map<String, dynamic>>> publishedPlaces() async {
    if (!isReady) return const [];
    final snapshot = await FirebaseFirestore.instance
        .collection('published_places')
        .where('published', isEqualTo: true)
        .limit(500)
        .get();
    return snapshot.docs
        .map((document) => {'id': document.id, ...document.data()})
        .toList();
  }

  static Stream<QuerySnapshot<Map<String, dynamic>>>
      publishedPlacesForGeneralManager() {
    return FirebaseFirestore.instance
        .collection('published_places')
        .limit(500)
        .snapshots();
  }

  static Stream<QuerySnapshot<Map<String, dynamic>>>
      deletedPlacesForGeneralManager() {
    return FirebaseFirestore.instance
        .collection('admin_trash_places')
        .orderBy('deletedAt', descending: true)
        .limit(500)
        .snapshots();
  }

  static Future<void> hidePublishedPlace(String id) async {
    final actor = await _requireGeneralManagerProfile();
    final cleanId = id.trim();
    if (cleanId.isEmpty) return;
    final ref =
        FirebaseFirestore.instance.collection('published_places').doc(cleanId);
    final snapshot = await ref.get();
    if (!snapshot.exists) throw StateError('published-place-not-found');

    await ref.update(<String, dynamic>{
      'published': false,
      'hiddenByManager': true,
      'hiddenAt': FieldValue.serverTimestamp(),
      'hiddenByUid': actor['uid'].toString(),
      'hiddenByName': actor['displayName'].toString(),
      'updatedAt': FieldValue.serverTimestamp(),
    });

    await _writeAdminAudit(
      'published_place_hidden',
      details: <String, dynamic>{
        'sourceCollection': 'published_places',
        'sourceId': cleanId,
        'placeName': snapshot.data()?['placeName'],
        'approvalNumber': snapshot.data()?['approvalNumber'],
      },
    );
  }

  static Future<void> restoreHiddenPublishedPlace(String id) async {
    final actor = await _requireGeneralManagerProfile();
    final cleanId = id.trim();
    if (cleanId.isEmpty) return;
    final ref =
        FirebaseFirestore.instance.collection('published_places').doc(cleanId);
    final snapshot = await ref.get();
    if (!snapshot.exists) throw StateError('published-place-not-found');

    await ref.update(<String, dynamic>{
      'published': true,
      'hiddenByManager': FieldValue.delete(),
      'hiddenAt': FieldValue.delete(),
      'hiddenByUid': FieldValue.delete(),
      'hiddenByName': FieldValue.delete(),
      'updatedAt': FieldValue.serverTimestamp(),
    });

    await _writeAdminAudit(
      'published_place_restored',
      details: <String, dynamic>{
        'sourceCollection': 'published_places',
        'sourceId': cleanId,
        'placeName': snapshot.data()?['placeName'],
        'approvalNumber': snapshot.data()?['approvalNumber'],
        'restoredByUid': actor['uid'],
      },
    );
  }

  static Future<void> trashPublishedPlace(String id) async {
    final actor = await _requireGeneralManagerProfile();
    final cleanId = id.trim();
    if (cleanId.isEmpty) return;
    final firestore = FirebaseFirestore.instance;
    final source = firestore.collection('published_places').doc(cleanId);
    final trash = firestore.collection('admin_trash_places').doc(cleanId);

    Map<String, dynamic>? placeData;
    await firestore.runTransaction((transaction) async {
      final snapshot = await transaction.get(source);
      if (!snapshot.exists || snapshot.data() == null) {
        throw StateError('published-place-not-found');
      }
      placeData = Map<String, dynamic>.from(snapshot.data()!);
      transaction.set(trash, <String, dynamic>{
        ...placeData!,
        'originalId': cleanId,
        'trashKind': 'published_place',
        'deletedFromCollection': 'published_places',
        'deletedAt': FieldValue.serverTimestamp(),
        'deletedByUid': actor['uid'].toString(),
        'deletedByName': actor['displayName'].toString(),
        'deletedByRole': normalizeAdminRole(actor['role']),
      });
      transaction.delete(source);
    });

    await _writeAdminAudit(
      'published_place_deleted',
      details: <String, dynamic>{
        'sourceCollection': 'published_places',
        'sourceId': cleanId,
        'placeName': placeData?['placeName'],
        'approvalNumber': placeData?['approvalNumber'],
      },
    );
  }

  static Future<void> restoreDeletedPublishedPlace(String id) async {
    final actor = await _requireGeneralManagerProfile();
    final cleanId = id.trim();
    if (cleanId.isEmpty) return;
    final firestore = FirebaseFirestore.instance;
    final trash = firestore.collection('admin_trash_places').doc(cleanId);
    final source = firestore.collection('published_places').doc(cleanId);

    await firestore.runTransaction((transaction) async {
      final snapshot = await transaction.get(trash);
      if (!snapshot.exists || snapshot.data() == null) {
        throw StateError('deleted-place-not-found');
      }
      final restored = Map<String, dynamic>.from(snapshot.data()!);
      for (final key in <String>[
        'originalId',
        'trashKind',
        'deletedFromCollection',
        'deletedAt',
        'deletedByUid',
        'deletedByName',
        'deletedByRole',
        'hiddenByManager',
        'hiddenAt',
        'hiddenByUid',
        'hiddenByName',
      ]) {
        restored.remove(key);
      }
      restored['published'] = true;
      restored['updatedAt'] = FieldValue.serverTimestamp();
      transaction.set(source, restored);
      transaction.delete(trash);
    });

    await _writeAdminAudit(
      'published_place_restored_from_trash',
      details: <String, dynamic>{
        'sourceCollection': 'published_places',
        'sourceId': cleanId,
        'restoredByUid': actor['uid'],
      },
    );
  }

  static Future<void> permanentlyDeletePublishedPlace(String id) async {
    final actor = await _requireGeneralManagerProfile();
    final cleanId = id.trim();
    if (cleanId.isEmpty) return;
    final trash = FirebaseFirestore.instance
        .collection('admin_trash_places')
        .doc(cleanId);
    final snapshot = await trash.get();
    if (!snapshot.exists || snapshot.data() == null) {
      throw StateError('deleted-place-not-found');
    }
    final data = snapshot.data()!;
    await trash.delete();

    await _writeAdminAudit(
      'published_place_permanently_deleted',
      details: <String, dynamic>{
        'sourceCollection': 'published_places',
        'sourceId': cleanId,
        'placeName': data['placeName'],
        'approvalNumber': data['approvalNumber'],
        'deletedByUid': actor['uid'],
      },
    );
  }

  static Future<void> markRequestViewed({
    required String collection,
    required String id,
  }) async {
    final actor = await _adminIdentity();
    final firestore = FirebaseFirestore.instance;
    final request = firestore.collection(collection).doc(id);
    await firestore.runTransaction((transaction) async {
      final snapshot = await transaction.get(request);
      if (!snapshot.exists) throw StateError('request-not-found');
      final data = snapshot.data() ?? <String, dynamic>{};
      final update = <String, dynamic>{
        'lastViewedAt': FieldValue.serverTimestamp(),
        'lastViewedByUid': actor['uid'],
        'lastViewedByName': actor['name'],
        'lastViewedByRole': actor['role'],
      };
      if (data['firstViewedAt'] == null) {
        update.addAll({
          'firstViewedAt': FieldValue.serverTimestamp(),
          'firstViewedByUid': actor['uid'],
          'firstViewedByName': actor['name'],
          'firstViewedByRole': actor['role'],
        });
      }
      transaction.update(request, update);
    });
    await _writeAdminAudit(
      'request_viewed',
      details: <String, dynamic>{
        'sourceCollection': collection,
        'sourceId': id,
      },
    );
  }

  static String _formatApprovalDate(DateTime value) {
    String two(int value) => value.toString().padLeft(2, '0');
    return '${two(value.day)}/${two(value.month)}/${value.year}';
  }

  static String _approvalMessage({
    required String placeName,
    required String approvalNumber,
    required String approvalDate,
  }) {
    return 'تم اعتماد: $placeName\n'
        'رقم الاعتماد: $approvalNumber\n'
        'تاريخ الاعتماد: $approvalDate\n'
        'DEDA - الدليل الدقيق';
  }

  static Future<Map<String, dynamic>> preparePlaceApproval(String id) async {
    final actor = await _adminIdentity();
    final firestore = FirebaseFirestore.instance;
    final request = firestore.collection('place_requests').doc(id);
    final counter =
        firestore.collection('system_counters').doc('place_approval');

    return firestore.runTransaction<Map<String, dynamic>>((transaction) async {
      final requestSnapshot = await transaction.get(request);
      if (!requestSnapshot.exists) throw StateError('place-request-not-found');
      final data = requestSnapshot.data()!;
      if (!_hasRequiredPlaceData(data)) {
        throw StateError('incomplete-place-request');
      }

      var approvalNumber = (data['approvalNumber'] ?? '').toString().trim();
      var approvalDate = (data['approvalDate'] ?? '').toString().trim();
      final requestType = (data['requestType'] ?? '').toString().trim();
      final originalPlaceId = (data['originalPlaceId'] ?? '').toString().trim();

      // An edit to an already approved place never receives a new DEDA
      // approval number. Always recover the immutable approval identity from
      // the original published place, even if this edit request previously
      // cached an incorrect prepared number.
      if (requestType == 'update' && originalPlaceId.isNotEmpty) {
        final original =
            firestore.collection('published_places').doc(originalPlaceId);
        final originalSnapshot = await transaction.get(original);
        final originalData = originalSnapshot.data();
        if (!originalSnapshot.exists || originalData == null) {
          throw StateError('original-published-place-not-found');
        }
        approvalNumber =
            (originalData['approvalNumber'] ?? '').toString().trim();
        approvalDate = (originalData['approvalDate'] ?? '').toString().trim();
        if (approvalNumber.isEmpty || approvalDate.isEmpty) {
          throw StateError('original-place-approval-missing');
        }
      } else if (approvalNumber.isEmpty) {
        final counterSnapshot = await transaction.get(counter);
        final current =
            (counterSnapshot.data()?['value'] as num?)?.toInt() ?? 0;
        final next = current + 1;
        final now = DateTime.now();
        approvalNumber = 'DEDA-${now.year}-${next.toString().padLeft(7, '0')}';
        approvalDate = _formatApprovalDate(now);
        transaction.set(
          counter,
          {'value': next, 'updatedAt': FieldValue.serverTimestamp()},
          SetOptions(merge: true),
        );
      }
      if (approvalDate.isEmpty) {
        approvalDate = _formatApprovalDate(DateTime.now());
      }
      final placeName = (data['placeName'] ?? '').toString().trim();
      final message = _approvalMessage(
        placeName: placeName,
        approvalNumber: approvalNumber,
        approvalDate: approvalDate,
      );
      transaction.update(request, {
        'approvalNumber': approvalNumber,
        'approvalDate': approvalDate,
        'approvalMessageDraft': message,
        'approvalPreparedAt': FieldValue.serverTimestamp(),
        'approvalPreparedByUid': actor['uid'],
        'approvalPreparedByName': actor['name'],
      });
      return {
        'approvalNumber': approvalNumber,
        'approvalDate': approvalDate,
        'placeName': placeName,
        'message': message,
      };
    });
  }

  static Future<void> finalizePlaceApproval({
    required String id,
    required String message,
  }) async {
    final actor = await _adminIdentity();
    final firestore = FirebaseFirestore.instance;
    final request = firestore.collection('place_requests').doc(id);
    final editNotification = firestore
        .collection('owner_place_notifications')
        .doc('edit_approved_' + id);
    Map<String, String>? editNotificationAudit;

    await firestore.runTransaction((transaction) async {
      final snapshot = await transaction.get(request);
      if (!snapshot.exists) throw StateError('place-request-not-found');
      final data = snapshot.data()!;
      if (!_hasRequiredPlaceData(data)) {
        throw StateError('incomplete-place-request');
      }
      var approvalNumber = (data['approvalNumber'] ?? '').toString().trim();
      var approvalDate = (data['approvalDate'] ?? '').toString().trim();
      final requestType = (data['requestType'] ?? '').toString().trim();
      final originalPlaceId = (data['originalPlaceId'] ?? '').toString().trim();
      final publishedId = originalPlaceId.isNotEmpty ? originalPlaceId : id;
      final published =
          firestore.collection('published_places').doc(publishedId);

      // Defense in depth: final approval of an edit must use the original
      // published place identity even if a stale preview/message carried a
      // different approval number.
      if (requestType == 'update' && originalPlaceId.isNotEmpty) {
        final originalSnapshot = await transaction.get(published);
        final originalData = originalSnapshot.data();
        if (!originalSnapshot.exists || originalData == null) {
          throw StateError('original-published-place-not-found');
        }
        approvalNumber =
            (originalData['approvalNumber'] ?? '').toString().trim();
        approvalDate = (originalData['approvalDate'] ?? '').toString().trim();
      }
      if (approvalNumber.isEmpty || approvalDate.isEmpty) {
        throw StateError('approval-not-prepared');
      }

      final generatedMessage = _approvalMessage(
        placeName: (data['placeName'] ?? '').toString(),
        approvalNumber: approvalNumber,
        approvalDate: approvalDate,
      );
      final cleanMessage = requestType == 'update'
          ? generatedMessage
          : (message.trim().isEmpty ? generatedMessage : message.trim());

      transaction.update(request, {
        'status': 'approved',
        'approvalNumber': approvalNumber,
        'approvalDate': approvalDate,
        'updatedAt': FieldValue.serverTimestamp(),
        'reviewedBy': actor['uid'],
        'reviewedByName': actor['name'],
        'reviewedByRole': actor['role'],
        'decisionAction': 'approved',
        'decisionAt': FieldValue.serverTimestamp(),
        'decisionByUid': actor['uid'],
        'decisionByName': actor['name'],
        'decisionByRole': actor['role'],
        'decisionNote': '',
        'approvalMessage': cleanMessage,
      });

      transaction.set(
        published,
        {
          ...data,
          'requestId': publishedId,
          'sourceRequestId': id,
          'lastSourceRequestId': id,
          'published': true,
          'status': 'approved',
          'approvalNumber': approvalNumber,
          'approvalDate': approvalDate,
          'approvalMessage': cleanMessage,
          'approvedByUid': actor['uid'],
          'approvedByName': actor['name'],
          'approvedByRole': actor['role'],
          'publishedAt': FieldValue.serverTimestamp(),
          'updatedAt': FieldValue.serverTimestamp(),
        },
        SetOptions(merge: true),
      );

      final accountKey = (data['accountKey'] ?? '').toString().trim();
      if (requestType == 'update' && accountKey.isNotEmpty) {
        final ownerUid = (data['ownerUid'] ?? '').toString().trim();
        final placeName = (data['placeName'] ?? '').toString().trim();
        final governorate = (data['governorate'] ?? '').toString().trim();
        const titleAr = 'تم اعتماد تعديل المكان';
        const titleEn = 'Place changes approved';
        final bodyAr = 'تم اعتماد التعديلات الخاصة بمكان «' +
            placeName +
            '» وتحديث بياناته في DEDA.';
        final bodyEn = 'The changes for “' +
            placeName +
            '” were approved and the place information was updated in DEDA.';
        transaction.set(
          editNotification,
          _ownerNotificationPayload(
            actor: actor,
            type: 'edit_approved',
            accountKey: accountKey,
            ownerUid: ownerUid,
            placeId: publishedId,
            placeName: placeName,
            approvalNumber: approvalNumber,
            governorate: governorate,
            titleAr: titleAr,
            titleEn: titleEn,
            bodyAr: bodyAr,
            bodyEn: bodyEn,
            sourceType: 'place_requests',
            sourceId: id,
          ),
        );
        editNotificationAudit = <String, String>{
          'accountKey': accountKey,
          'placeId': publishedId,
          'placeName': placeName,
          'titleAr': titleAr,
          'bodyAr': bodyAr,
        };
      }
    });
    await _writeAdminAudit(
      'place_approved',
      details: <String, dynamic>{
        'sourceCollection': 'place_requests',
        'sourceId': id,
      },
    );
    final editAudit = editNotificationAudit;
    if (editAudit != null) {
      await _writeOwnerNotificationAudit(
        notificationType: 'edit_approved',
        sourceType: 'place_requests',
        sourceId: id,
        placeId: editAudit['placeId'] ?? '',
        placeName: editAudit['placeName'] ?? '',
        accountKey: editAudit['accountKey'] ?? '',
        titleAr: editAudit['titleAr'] ?? '',
        bodyAr: editAudit['bodyAr'] ?? '',
      );
    }
  }

  static Future<void> updateRequestStatus({
    required String collection,
    required String id,
    required String status,
    String? note,
  }) async {
    if (collection == 'place_requests' && status == 'approved') {
      final prepared = await preparePlaceApproval(id);
      await finalizePlaceApproval(
          id: id, message: prepared['message'].toString());
      return;
    }

    if ((status == 'rejected' || status == 'needs_changes') &&
        (note == null || note.trim().isEmpty)) {
      throw ArgumentError('reason-required');
    }

    final actor = await _adminIdentity();
    final firestore = FirebaseFirestore.instance;
    final request = firestore.collection(collection).doc(id);
    final statusUpdate = <String, dynamic>{
      'status': status,
      'updatedAt': FieldValue.serverTimestamp(),
      'reviewedBy': actor['uid'],
      'reviewedByName': actor['name'],
      'reviewedByRole': actor['role'],
    };
    if (status == 'rejected' || status == 'needs_changes') {
      statusUpdate.addAll({
        'decisionAction': status,
        'decisionAt': FieldValue.serverTimestamp(),
        'decisionByUid': actor['uid'],
        'decisionByName': actor['name'],
        'decisionByRole': actor['role'],
        'decisionNote': note?.trim() ?? '',
      });
    }
    Map<String, String>? needsChangesAudit;
    if (collection == 'place_requests' && status == 'needs_changes') {
      final snapshot = await request.get();
      final data = snapshot.data();
      if (!snapshot.exists || data == null) {
        throw StateError('place-request-not-found');
      }
      final accountKey = (data['accountKey'] ?? '').toString().trim();
      if (accountKey.isNotEmpty) {
        final ownerUid = (data['ownerUid'] ?? '').toString().trim();
        final placeName = (data['placeName'] ?? '').toString().trim();
        final originalPlaceId =
            (data['originalPlaceId'] ?? '').toString().trim();
        final placeId = originalPlaceId.isNotEmpty ? originalPlaceId : id;
        final approvalNumber = (data['approvalNumber'] ?? '').toString().trim();
        final governorate = (data['governorate'] ?? '').toString().trim();
        const titleAr = 'يحتاج طلبك تعديل';
        const titleEn = 'Your request needs changes';
        final cleanNote = note?.trim() ?? '';
        final bodyAr = 'طلب المكان «' +
            placeName +
            '» يحتاج إلى تعديل قبل اعتماده.' +
            (cleanNote.isEmpty ? '' : ' ملاحظة الإدارة: ' + cleanNote);
        final bodyEn = 'The request for “' +
            placeName +
            '” needs changes before it can be approved.' +
            (cleanNote.isEmpty ? '' : ' Administration note: ' + cleanNote);
        final notification =
            firestore.collection('owner_place_notifications').doc();
        final batch = firestore.batch();
        batch.update(request, statusUpdate);
        batch.set(
          notification,
          _ownerNotificationPayload(
            actor: actor,
            type: 'needs_changes',
            accountKey: accountKey,
            ownerUid: ownerUid,
            placeId: placeId,
            placeName: placeName,
            approvalNumber: approvalNumber,
            governorate: governorate,
            titleAr: titleAr,
            titleEn: titleEn,
            bodyAr: bodyAr,
            bodyEn: bodyEn,
            sourceType: 'place_requests',
            sourceId: id,
          ),
        );
        await batch.commit();
        needsChangesAudit = <String, String>{
          'accountKey': accountKey,
          'placeId': placeId,
          'placeName': placeName,
          'titleAr': titleAr,
          'bodyAr': bodyAr,
        };
      } else {
        await request.update(statusUpdate);
      }
    } else {
      await request.update(statusUpdate);
    }
    await _writeAdminAudit(
      collection == 'place_requests'
          ? 'place_status_changed'
          : 'request_status_changed',
      details: <String, dynamic>{
        'sourceCollection': collection,
        'sourceId': id,
        'newStatus': status,
        if (note != null && note.trim().isNotEmpty) 'reason': note.trim(),
      },
    );
    final needsAudit = needsChangesAudit;
    if (needsAudit != null) {
      await _writeOwnerNotificationAudit(
        notificationType: 'needs_changes',
        sourceType: 'place_requests',
        sourceId: id,
        placeId: needsAudit['placeId'] ?? '',
        placeName: needsAudit['placeName'] ?? '',
        accountKey: needsAudit['accountKey'] ?? '',
        titleAr: needsAudit['titleAr'] ?? '',
        bodyAr: needsAudit['bodyAr'] ?? '',
      );
    }
  }

  // DEDA 10-point fixes v1: support replies and read-only account review.
  static Stream<Map<String, dynamic>?> publishedPlaceStream(String id) {
    return FirebaseFirestore.instance
        .collection('published_places')
        .doc(id)
        .snapshots()
        .map((snapshot) => snapshot.exists && snapshot.data() != null
            ? <String, dynamic>{'id': snapshot.id, ...snapshot.data()!}
            : null);
  }

  static Future<List<Map<String, dynamic>>> mySupportRequests({
    required String phone,
  }) async {
    final user = await _ensurePublicUser();
    final accountKey = accountKeyForPhone(phone);
    final firestore = FirebaseFirestore.instance;
    final byId = <String, Map<String, dynamic>>{};

    // New records are account-key based, so the same phone sees the same
    // support history on another device. Keep UID fallback for older tickets.
    try {
      final snapshot = await firestore
          .collection('support_requests')
          .where('accountKey', isEqualTo: accountKey)
          .limit(50)
          .get();
      for (final doc in snapshot.docs) {
        byId[doc.id] = <String, dynamic>{'id': doc.id, ...doc.data()};
      }
    } catch (_) {}

    try {
      final snapshot = await firestore
          .collection('support_requests')
          .where('ownerUid', isEqualTo: user.uid)
          .limit(50)
          .get();
      for (final doc in snapshot.docs) {
        byId[doc.id] = <String, dynamic>{'id': doc.id, ...doc.data()};
      }
    } catch (_) {}

    final items = byId.values.toList();
    int millis(dynamic value) =>
        value is Timestamp ? value.millisecondsSinceEpoch : 0;
    items.sort(
        (a, b) => millis(b['createdAt']).compareTo(millis(a['createdAt'])));
    return items;
  }

  static Stream<QuerySnapshot<Map<String, dynamic>>>
      deletedSupportRequestsForAdmin() {
    return FirebaseFirestore.instance
        .collection('admin_trash_support')
        .orderBy('deletedAt', descending: true)
        .limit(500)
        .snapshots();
  }

  static Future<Map<String, dynamic>> _requireGeneralManagerProfile() async {
    final actor = await currentAdminProfile();
    if (normalizeAdminRole(actor['role']) != 'general_manager') {
      throw StateError('general-manager-required');
    }
    return actor;
  }

  static Future<void> trashSupportRequest(String id) async {
    await trashSupportRequests(<String>[id]);
  }

  static Future<void> trashSupportRequests(List<String> ids) async {
    final actor = await _requireGeneralManagerProfile();
    final uniqueIds = ids
        .map((value) => value.trim())
        .where((value) => value.isNotEmpty)
        .toSet()
        .take(100)
        .toList();
    if (uniqueIds.isEmpty) return;

    final firestore = FirebaseFirestore.instance;
    final batch = firestore.batch();
    final moved = <String>[];

    for (final id in uniqueIds) {
      final source = firestore.collection('support_requests').doc(id);
      final snapshot = await source.get();
      if (!snapshot.exists || snapshot.data() == null) continue;
      final data = snapshot.data()!;
      final trash = firestore.collection('admin_trash_support').doc(id);
      batch.set(trash, <String, dynamic>{
        ...data,
        'originalId': id,
        'trashKind': 'support_request',
        'deletedFromCollection': 'support_requests',
        'deletedAt': FieldValue.serverTimestamp(),
        'deletedByUid': actor['uid'].toString(),
        'deletedByName': actor['displayName'].toString(),
        'deletedByRole': normalizeAdminRole(actor['role']),
      });
      batch.delete(source);
      moved.add(id);
    }

    if (moved.isEmpty) return;
    await batch.commit();
    await _writeAdminAudit(
      moved.length == 1 ? 'support_deleted' : 'support_bulk_deleted',
      details: <String, dynamic>{
        'sourceCollection': 'support_requests',
        'sourceId': moved.length == 1 ? moved.first : '',
        'deletedCount': moved.length,
        'deletedIds': moved,
      },
    );
  }

  static Future<void> restoreDeletedSupportRequest(String id) async {
    final actor = await _requireGeneralManagerProfile();
    final cleanId = id.trim();
    if (cleanId.isEmpty) return;
    final firestore = FirebaseFirestore.instance;
    final trash = firestore.collection('admin_trash_support').doc(cleanId);
    final source = firestore.collection('support_requests').doc(cleanId);

    await firestore.runTransaction((transaction) async {
      final snapshot = await transaction.get(trash);
      if (!snapshot.exists || snapshot.data() == null) {
        throw StateError('deleted-support-not-found');
      }
      final restored = Map<String, dynamic>.from(snapshot.data()!);
      for (final key in <String>[
        'originalId',
        'trashKind',
        'deletedFromCollection',
        'deletedAt',
        'deletedByUid',
        'deletedByName',
        'deletedByRole',
      ]) {
        restored.remove(key);
      }
      restored['updatedAt'] = FieldValue.serverTimestamp();
      transaction.set(source, restored);
      transaction.delete(trash);
    });

    await _writeAdminAudit(
      'support_restored',
      details: <String, dynamic>{
        'sourceCollection': 'support_requests',
        'sourceId': cleanId,
        'restoredByUid': actor['uid'],
      },
    );
  }

  static Future<void> permanentlyDeleteSupportRequest(String id) async {
    final actor = await _requireGeneralManagerProfile();
    final cleanId = id.trim();
    if (cleanId.isEmpty) return;
    final firestore = FirebaseFirestore.instance;
    final trash = firestore.collection('admin_trash_support').doc(cleanId);
    final snapshot = await trash.get();
    if (!snapshot.exists || snapshot.data() == null) {
      throw StateError('deleted-support-not-found');
    }
    final data = snapshot.data()!;
    final imageUrls = <String>{};
    final rawImageUrls = data['imageUrls'];
    if (rawImageUrls is List) {
      for (final value in rawImageUrls) {
        final url = value?.toString().trim() ?? '';
        if (url.isNotEmpty) imageUrls.add(url);
      }
    }
    final legacyImageUrl = (data['imageUrl'] ?? '').toString().trim();
    if (legacyImageUrl.isNotEmpty) imageUrls.add(legacyImageUrl);

    await trash.delete();

    for (final imageUrl in imageUrls) {
      try {
        await FirebaseStorage.instance.refFromURL(imageUrl).delete();
      } catch (_) {
        // The support record is already permanently removed. Storage cleanup
        // is best effort so a stale/missing file never blocks the deletion.
      }
    }

    await _writeAdminAudit(
      'support_permanently_deleted',
      details: <String, dynamic>{
        'sourceCollection': 'support_requests',
        'sourceId': cleanId,
        'targetUserName': data['name'],
        'targetUserPhone': data['phone'],
        'deletedByUid': actor['uid'],
      },
    );
  }

  static Stream<QuerySnapshot<Map<String, dynamic>>>
      deletedPlaceRequestsForAdmin() {
    return FirebaseFirestore.instance
        .collection('admin_trash_place_requests')
        .orderBy('deletedAt', descending: true)
        .limit(500)
        .snapshots();
  }

  static Future<void> trashPlaceRequest(String id) async {
    await trashPlaceRequests(<String>[id]);
  }

  static Future<void> trashPlaceRequests(List<String> ids) async {
    final actor = await _requireGeneralManagerProfile();
    final uniqueIds = ids
        .map((value) => value.trim())
        .where((value) => value.isNotEmpty)
        .toSet()
        .take(100)
        .toList();
    if (uniqueIds.isEmpty) return;

    final firestore = FirebaseFirestore.instance;
    final batch = firestore.batch();
    final moved = <String>[];

    for (final id in uniqueIds) {
      final source = firestore.collection('place_requests').doc(id);
      final snapshot = await source.get();
      if (!snapshot.exists || snapshot.data() == null) continue;
      final data = snapshot.data()!;
      final trash = firestore.collection('admin_trash_place_requests').doc(id);
      batch.set(trash, <String, dynamic>{
        ...data,
        'originalId': id,
        'trashKind': 'place_request',
        'deletedFromCollection': 'place_requests',
        'deletedAt': FieldValue.serverTimestamp(),
        'deletedByUid': actor['uid'].toString(),
        'deletedByName': actor['displayName'].toString(),
        'deletedByRole': normalizeAdminRole(actor['role']),
      });
      batch.delete(source);
      moved.add(id);
    }

    if (moved.isEmpty) return;
    await batch.commit();
    await _writeAdminAudit(
      moved.length == 1
          ? 'place_request_deleted'
          : 'place_requests_bulk_deleted',
      details: <String, dynamic>{
        'sourceCollection': 'place_requests',
        'sourceId': moved.length == 1 ? moved.first : '',
        'deletedCount': moved.length,
        'deletedIds': moved,
      },
    );
  }

  static Future<void> restoreDeletedPlaceRequest(String id) async {
    final actor = await _requireGeneralManagerProfile();
    final cleanId = id.trim();
    if (cleanId.isEmpty) return;
    final firestore = FirebaseFirestore.instance;
    final trash =
        firestore.collection('admin_trash_place_requests').doc(cleanId);
    final source = firestore.collection('place_requests').doc(cleanId);

    await firestore.runTransaction((transaction) async {
      final snapshot = await transaction.get(trash);
      if (!snapshot.exists || snapshot.data() == null) {
        throw StateError('deleted-place-request-not-found');
      }
      final restored = Map<String, dynamic>.from(snapshot.data()!);
      for (final key in <String>[
        'originalId',
        'trashKind',
        'deletedFromCollection',
        'deletedAt',
        'deletedByUid',
        'deletedByName',
        'deletedByRole',
      ]) {
        restored.remove(key);
      }
      restored['updatedAt'] = FieldValue.serverTimestamp();
      transaction.set(source, restored);
      transaction.delete(trash);
    });

    await _writeAdminAudit(
      'place_request_restored',
      details: <String, dynamic>{
        'sourceCollection': 'place_requests',
        'sourceId': cleanId,
        'restoredByUid': actor['uid'],
      },
    );
  }

  static Future<void> permanentlyDeletePlaceRequest(String id) async {
    final actor = await _requireGeneralManagerProfile();
    final cleanId = id.trim();
    if (cleanId.isEmpty) return;

    final firestore = FirebaseFirestore.instance;
    final trash =
        firestore.collection('admin_trash_place_requests').doc(cleanId);
    final snapshot = await trash.get();
    if (!snapshot.exists || snapshot.data() == null) {
      throw StateError('deleted-place-request-not-found');
    }
    final data = snapshot.data()!;

    // Only the archived request is removed. An already published place is a
    // separate record and must never be affected by deleting request history.
    await trash.delete();

    await _writeAdminAudit(
      'place_request_permanently_deleted',
      details: <String, dynamic>{
        'sourceCollection': 'place_requests',
        'sourceId': cleanId,
        'targetPlaceName': data['placeName'] ?? data['name'],
        'targetPhone': data['phone'],
        'approvalNumber': data['approvalNumber'],
        'deletedByUid': actor['uid'],
      },
    );
  }

  static Future<void> updateSupportStatus({
    required String id,
    required String status,
  }) async {
    const allowed = {'new', 'in_progress', 'replied', 'closed'};
    if (!allowed.contains(status))
      throw ArgumentError('invalid-support-status');
    final actor = await _adminIdentity();
    await FirebaseFirestore.instance
        .collection('support_requests')
        .doc(id)
        .update({
      'status': status,
      'updatedAt': FieldValue.serverTimestamp(),
      'reviewedBy': actor['uid'],
      'reviewedByName': actor['name'],
      'reviewedByRole': actor['role'],
      if (status == 'closed') 'closedAt': FieldValue.serverTimestamp(),
    });
    await _writeAdminAudit(
      'support_status_changed',
      details: <String, dynamic>{
        'sourceCollection': 'support_requests',
        'sourceId': id,
        'newStatus': status,
      },
    );
  }

  static Future<void> replyToSupport({
    required String id,
    required String message,
  }) async {
    final clean = message.trim();
    if (clean.isEmpty) throw ArgumentError('empty-support-reply');
    final actor = await _adminIdentity();
    await FirebaseFirestore.instance
        .collection('support_requests')
        .doc(id)
        .update({
      'status': 'replied',
      'adminReply': clean,
      'adminReplyAt': FieldValue.serverTimestamp(),
      'adminReplyByUid': actor['uid'],
      'adminReplyByName': actor['name'],
      'adminReplyByRole': actor['role'],
      'updatedAt': FieldValue.serverTimestamp(),
    });
    await _writeAdminAudit(
      'support_replied',
      details: <String, dynamic>{
        'sourceCollection': 'support_requests',
        'sourceId': id,
      },
    );
  }

  static Future<Map<String, dynamic>> adminUserSnapshot({
    required String ownerUid,
    required String sourceCollection,
    required String sourceId,
  }) async {
    final actor = await _adminIdentity();
    final firestore = FirebaseFirestore.instance;

    Map<String, dynamic> sourceData = <String, dynamic>{};
    try {
      final source =
          await firestore.collection(sourceCollection).doc(sourceId).get();
      sourceData = source.data() ?? <String, dynamic>{};
    } catch (_) {}

    final sourcePhone = (sourceData['phone'] ?? '').toString().trim();
    final sourceKey = (sourceData['accountKey'] ?? '').toString().trim();
    final accountKey = sourceKey.isNotEmpty
        ? sourceKey
        : (sourcePhone.isNotEmpty ? accountKeyForPhone(sourcePhone) : '');

    Map<String, dynamic> profile = <String, dynamic>{};
    try {
      final user = await firestore.collection('users').doc(ownerUid).get();
      profile = user.data() ?? <String, dynamic>{};
    } catch (_) {}
    if (profile.isEmpty && accountKey.isNotEmpty) {
      try {
        final users = await firestore
            .collection('users')
            .where('accountKey', isEqualTo: accountKey)
            .limit(1)
            .get();
        if (users.docs.isNotEmpty) profile = users.docs.first.data();
      } catch (_) {}
    }
    profile = <String, dynamic>{
      'name': profile['name'] ?? sourceData['name'] ?? '',
      'phone': profile['phone'] ?? sourceData['phone'] ?? '',
      'accountType': profile['accountType'] ?? sourceData['accountType'] ?? '',
      'accountKey': profile['accountKey'] ?? accountKey,
      ...profile,
    };

    Future<List<Map<String, dynamic>>> owned(String collection) async {
      final byId = <String, Map<String, dynamic>>{};
      if (accountKey.isNotEmpty) {
        try {
          final snapshot = await firestore
              .collection(collection)
              .where('accountKey', isEqualTo: accountKey)
              .limit(50)
              .get();
          for (final doc in snapshot.docs) {
            byId[doc.id] = <String, dynamic>{'id': doc.id, ...doc.data()};
          }
        } catch (_) {}
      }
      try {
        final snapshot = await firestore
            .collection(collection)
            .where('ownerUid', isEqualTo: ownerUid)
            .limit(50)
            .get();
        for (final doc in snapshot.docs) {
          byId[doc.id] = <String, dynamic>{'id': doc.id, ...doc.data()};
        }
      } catch (_) {}
      return byId.values.toList();
    }

    final placeRequests = await owned('place_requests');
    final published = await owned('published_places');
    final support = await owned('support_requests');

    // Always attempt an audit record. If that collection has not been deployed
    // yet, record the review on the source ticket/request instead so the action
    // remains traceable and the read-only window still opens.
    try {
      // A single tap can occasionally trigger the same async open twice on a
      // slow device. Use a short deterministic bucket so concurrent duplicate
      // calls collapse into one audit record, while later genuine views still
      // create a new entry.
      final auditBucket = DateTime.now().millisecondsSinceEpoch ~/ 5000;
      final auditId = 'read_${actor['uid']}_${ownerUid}_$auditBucket';
      await firestore.collection('admin_audit').doc(auditId).set({
        'action': 'read_user_account',
        'ownerUid': ownerUid,
        'accountKey': accountKey,
        'targetUserName': (profile['name'] ?? '').toString().trim(),
        'targetUserPhone': (profile['phone'] ?? sourcePhone).toString().trim(),
        'sourceCollection': sourceCollection,
        'sourceId': sourceId,
        'adminUid': actor['uid'],
        'adminName': actor['name'],
        'adminRole': actor['role'],
        'createdAt': FieldValue.serverTimestamp(),
      });
    } catch (_) {}
    try {
      await firestore.collection(sourceCollection).doc(sourceId).update({
        'accountReviewedAt': FieldValue.serverTimestamp(),
        'accountReviewedByUid': actor['uid'],
        'accountReviewedByName': actor['name'],
        'accountReviewedByRole': actor['role'],
      });
    } catch (_) {}

    return <String, dynamic>{
      'uid': ownerUid,
      'accountKey': accountKey,
      'profile': profile,
      'placeRequests': placeRequests,
      'publishedPlaces': published,
      'supportRequests': support,
    };
  }

  static Stream<QuerySnapshot<Map<String, dynamic>>> adminMembers() {
    return FirebaseFirestore.instance
        .collection('admins')
        .limit(500)
        .snapshots();
  }

  static Stream<QuerySnapshot<Map<String, dynamic>>> adminInvitations() {
    return FirebaseFirestore.instance
        .collection('admin_invites')
        .orderBy('createdAt', descending: true)
        .limit(100)
        .snapshots();
  }

  static Stream<QuerySnapshot<Map<String, dynamic>>> adminAudit() {
    return FirebaseFirestore.instance
        .collection('admin_audit')
        .orderBy('createdAt', descending: true)
        .limit(300)
        .snapshots();
  }

  static Stream<QuerySnapshot<Map<String, dynamic>>> adminUsers() {
    return FirebaseFirestore.instance
        .collection('users')
        .limit(500)
        .snapshots();
  }

  static Stream<QuerySnapshot<Map<String, dynamic>>>
      placeDeletionRequestsForAdmin() {
    return FirebaseFirestore.instance
        .collection('place_deletion_requests')
        .orderBy('updatedAt', descending: true)
        .limit(500)
        .snapshots();
  }

  static Future<void> updatePlaceDeletionRequestStatus({
    required String requestId,
    required String status,
    String note = '',
  }) async {
    final actor = await currentAdminProfile();
    if (normalizeAdminRole(actor['role']) != 'general_manager') {
      throw StateError('general-manager-required');
    }
    if (!<String>{'reviewing', 'deleted', 'rejected', 'cancelled'}
        .contains(status)) {
      throw ArgumentError('invalid-place-deletion-status');
    }

    final firestore = FirebaseFirestore.instance;
    final requestRef =
        firestore.collection('place_deletion_requests').doc(requestId);

    Map<String, dynamic>? requestData;
    Map<String, String>? deletionNotificationAudit;
    if (status == 'deleted') {
      final notificationRef = firestore
          .collection('owner_place_notifications')
          .doc('deletion_approved_' + requestId);
      await firestore.runTransaction((transaction) async {
        final requestSnapshot = await transaction.get(requestRef);
        if (!requestSnapshot.exists || requestSnapshot.data() == null) {
          throw StateError('place-deletion-request-not-found');
        }
        final data = requestSnapshot.data()!;
        requestData = Map<String, dynamic>.from(data);
        final placeId = (data['placeId'] ?? requestId).toString().trim();
        if (placeId.isEmpty) throw StateError('place-id-required');

        final placeRef = firestore.collection('published_places').doc(placeId);
        final trashRef =
            firestore.collection('admin_trash_places').doc(placeId);
        final placeSnapshot = await transaction.get(placeRef);
        if (placeSnapshot.exists && placeSnapshot.data() != null) {
          final place = placeSnapshot.data()!;
          transaction.set(trashRef, <String, dynamic>{
            ...place,
            'originalId': placeId,
            'trashKind': 'owner_requested_place_deletion',
            'deletedFromCollection': 'published_places',
            'deletionRequestId': requestId,
            'deletedAt': FieldValue.serverTimestamp(),
            'deletedByUid': actor['uid'].toString(),
            'deletedByName': actor['displayName'].toString(),
            'deletedByRole': normalizeAdminRole(actor['role']),
          });
          transaction.delete(placeRef);
        }

        transaction.update(requestRef, <String, dynamic>{
          'status': 'deleted',
          'updatedAt': FieldValue.serverTimestamp(),
          'reviewedByUid': actor['uid'].toString(),
          'reviewedByName': actor['displayName'].toString(),
          'reviewedByRole': normalizeAdminRole(actor['role']),
          'reviewNote': note.trim(),
          'completedAt': FieldValue.serverTimestamp(),
        });

        final accountKey = (data['accountKey'] ?? '').toString().trim();
        if (accountKey.isNotEmpty) {
          final ownerUid = (data['requesterUid'] ?? '').toString().trim();
          final placeName = (data['placeName'] ?? '').toString().trim();
          final approvalNumber =
              (data['approvalNumber'] ?? '').toString().trim();
          final governorate = (data['governorate'] ?? '').toString().trim();
          const titleAr = 'تمت الموافقة على حذف المكان';
          const titleEn = 'Place deletion approved';
          final bodyAr = 'بناءً على طلبك السابق، تمت الموافقة على حذف «' +
              placeName +
              '» من DEDA. يمكنك الآن إنشاء مكان جديد من قسم «إدارة مكاني».';
          final bodyEn = 'Based on your previous request, “' +
              placeName +
              '” was removed from DEDA. You can now create a new place from Manage my place.';
          transaction.set(
            notificationRef,
            _ownerNotificationPayload(
              actor: actor,
              type: 'deletion_approved',
              accountKey: accountKey,
              ownerUid: ownerUid,
              placeId: placeId,
              placeName: placeName,
              approvalNumber: approvalNumber,
              governorate: governorate,
              titleAr: titleAr,
              titleEn: titleEn,
              bodyAr: bodyAr,
              bodyEn: bodyEn,
              sourceType: 'place_deletion_requests',
              sourceId: requestId,
            ),
          );
          deletionNotificationAudit = <String, String>{
            'type': 'deletion_approved',
            'accountKey': accountKey,
            'placeId': placeId,
            'placeName': placeName,
            'titleAr': titleAr,
            'bodyAr': bodyAr,
          };
        }
      });
    } else {
      final snapshot = await requestRef.get();
      if (!snapshot.exists || snapshot.data() == null) {
        throw StateError('place-deletion-request-not-found');
      }
      requestData = Map<String, dynamic>.from(snapshot.data()!);
      final update = <String, dynamic>{
        'status': status,
        'updatedAt': FieldValue.serverTimestamp(),
        'reviewedByUid': actor['uid'].toString(),
        'reviewedByName': actor['displayName'].toString(),
        'reviewedByRole': normalizeAdminRole(actor['role']),
        'reviewNote': note.trim(),
        if (status == 'rejected' || status == 'cancelled')
          'closedAt': FieldValue.serverTimestamp(),
      };
      if (status == 'rejected') {
        final data = requestData!;
        final accountKey = (data['accountKey'] ?? '').toString().trim();
        if (accountKey.isNotEmpty) {
          final placeId = (data['placeId'] ?? requestId).toString().trim();
          final ownerUid = (data['requesterUid'] ?? '').toString().trim();
          final placeName = (data['placeName'] ?? '').toString().trim();
          final approvalNumber =
              (data['approvalNumber'] ?? '').toString().trim();
          final governorate = (data['governorate'] ?? '').toString().trim();
          const titleAr = 'تم رفض طلب الحذف';
          const titleEn = 'Place deletion request rejected';
          final cleanNote = note.trim();
          final bodyAr = 'تمت مراجعة طلب حذف «' +
              placeName +
              '» ولم تتم الموافقة عليه.' +
              (cleanNote.isEmpty ? '' : ' ملاحظة الإدارة: ' + cleanNote);
          final bodyEn = 'The deletion request for “' +
              placeName +
              '” was reviewed and was not approved.' +
              (cleanNote.isEmpty ? '' : ' Administration note: ' + cleanNote);
          final notificationRef = firestore
              .collection('owner_place_notifications')
              .doc('deletion_rejected_' + requestId);
          final batch = firestore.batch();
          batch.update(requestRef, update);
          batch.set(
            notificationRef,
            _ownerNotificationPayload(
              actor: actor,
              type: 'deletion_rejected',
              accountKey: accountKey,
              ownerUid: ownerUid,
              placeId: placeId,
              placeName: placeName,
              approvalNumber: approvalNumber,
              governorate: governorate,
              titleAr: titleAr,
              titleEn: titleEn,
              bodyAr: bodyAr,
              bodyEn: bodyEn,
              sourceType: 'place_deletion_requests',
              sourceId: requestId,
            ),
          );
          await batch.commit();
          deletionNotificationAudit = <String, String>{
            'type': 'deletion_rejected',
            'accountKey': accountKey,
            'placeId': placeId,
            'placeName': placeName,
            'titleAr': titleAr,
            'bodyAr': bodyAr,
          };
        } else {
          await requestRef.update(update);
        }
      } else {
        await requestRef.update(update);
      }
    }

    await _writeAdminAudit(
      'place_deletion_status_changed',
      details: <String, dynamic>{
        'requestId': requestId,
        'placeId': requestData?['placeId'],
        'placeName': requestData?['placeName'],
        'approvalNumber': requestData?['approvalNumber'],
        'requesterUid': requestData?['requesterUid'],
        'newStatus': status,
        'note': note.trim(),
      },
    );
    final deletionAudit = deletionNotificationAudit;
    if (deletionAudit != null) {
      await _writeOwnerNotificationAudit(
        notificationType: deletionAudit['type'] ?? '',
        sourceType: 'place_deletion_requests',
        sourceId: requestId,
        placeId: deletionAudit['placeId'] ?? '',
        placeName: deletionAudit['placeName'] ?? '',
        accountKey: deletionAudit['accountKey'] ?? '',
        titleAr: deletionAudit['titleAr'] ?? '',
        bodyAr: deletionAudit['bodyAr'] ?? '',
      );
    }
  }

  static Stream<QuerySnapshot<Map<String, dynamic>>> accountDeletionRequests() {
    return FirebaseFirestore.instance
        .collection('account_deletion_requests')
        .orderBy('createdAt', descending: true)
        .limit(500)
        .snapshots();
  }

  static Future<String> submitAccountDeletionRequest({
    required String name,
    required String phone,
    String reason = '',
  }) async {
    final user = await _ensurePublicUser();
    final firestore = FirebaseFirestore.instance;
    final cleanName = name.trim();
    final cleanPhone = phone.trim();
    final accountKey = accountKeyForPhone(cleanPhone);
    final request = firestore.collection('account_deletion_requests').doc();

    await request.set(<String, dynamic>{
      'requesterUid': user.uid,
      'accountKey': accountKey,
      'name': cleanName,
      'phone': cleanPhone,
      'reason': reason.trim(),
      'status': 'new',
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
    return request.id;
  }

  static Future<void> updateAccountDeletionRequestStatus({
    required String requestId,
    required String status,
    String note = '',
  }) async {
    final actor = await currentAdminProfile();
    if (normalizeAdminRole(actor['role']) != 'general_manager') {
      throw StateError('general-manager-required');
    }
    const allowed = <String>{
      'new',
      'reviewing',
      'deleted',
      'cancelled',
      'rejected',
    };
    if (!allowed.contains(status)) {
      throw ArgumentError('invalid-account-deletion-status');
    }

    final ref = FirebaseFirestore.instance
        .collection('account_deletion_requests')
        .doc(requestId);
    final snapshot = await ref.get();
    if (!snapshot.exists) {
      throw StateError('account-deletion-request-not-found');
    }
    final current = snapshot.data() ?? <String, dynamic>{};

    final update = <String, dynamic>{
      'status': status,
      'updatedAt': FieldValue.serverTimestamp(),
      'reviewedByUid': actor['uid'].toString(),
      'reviewedByName': actor['displayName'].toString(),
      'reviewedByRole': normalizeAdminRole(actor['role']),
      'reviewNote': note.trim(),
    };
    if (status == 'deleted') {
      update['completedAt'] = FieldValue.serverTimestamp();
    }
    if (status == 'cancelled' || status == 'rejected') {
      update['closedAt'] = FieldValue.serverTimestamp();
    }

    await ref.update(update);
    await _writeAdminAudit(
      'account_deletion_status_changed',
      details: <String, dynamic>{
        'requestId': requestId,
        'targetUserUid': current['requesterUid'],
        'targetUserName': current['name'],
        'targetUserPhone': current['phone'],
        'oldStatus': current['status'],
        'newStatus': status,
        'note': note.trim(),
      },
    );
  }

  static const String prizeWinnerCycleId = 'prize_v1';

  static String _prizeWinnerRequestIdForPhone(String phone) {
    final accountKey = accountKeyForPhone(phone);
    if (accountKey.isEmpty) throw ArgumentError('prize-account-required');
    return '${prizeWinnerCycleId}_$accountKey';
  }

  static Stream<Map<String, dynamic>?> prizeWinnerRequestForUser(String phone) {
    final accountKey = accountKeyForPhone(phone);
    if (accountKey.isEmpty) return Stream<Map<String, dynamic>?>.value(null);
    return FirebaseFirestore.instance
        .collection('prize_winner_requests')
        .doc('${prizeWinnerCycleId}_$accountKey')
        .snapshots()
        .map((snapshot) => snapshot.exists && snapshot.data() != null
            ? <String, dynamic>{'id': snapshot.id, ...snapshot.data()!}
            : null);
  }

  static Future<String> submitPrizeWinnerRequest({
    required String name,
    required String phone,
    required String dedaId,
    required String rewardCode,
    required int pointsAtCompletion,
  }) async {
    final cleanPhone = phone.trim();
    final accountKey = accountKeyForPhone(cleanPhone);
    if (accountKey.isEmpty) throw ArgumentError('prize-account-required');
    final cleanCode = rewardCode.trim();
    if (cleanCode.length != 16) throw ArgumentError('prize-code-invalid');

    final user = await _ensureOwnerSessionForAccountKey(accountKey);
    final requestId = _prizeWinnerRequestIdForPhone(cleanPhone);
    final ref = FirebaseFirestore.instance
        .collection('prize_winner_requests')
        .doc(requestId);
    final existing = await ref.get();
    if (existing.exists) return requestId;

    await ref.set(<String, dynamic>{
      'ownerUid': user.uid,
      'cycleId': prizeWinnerCycleId,
      'accountKey': accountKey,
      'name': name.trim(),
      'phone': cleanPhone,
      'dedaId': dedaId.trim(),
      'rewardCode': cleanCode,
      'pointsAtCompletion': pointsAtCompletion,
      'completedThresholds': const <int>[5000, 10000, 15000, 20000, 25000],
      'finalReservedPoints': 25000,
      'status': 'new',
      'adminMessage': '',
      'prizeDetails': '',
      'userReply': '',
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
    return requestId;
  }

  static Future<void> replyToPrizeWinnerRequestFromUser({
    required String phone,
    required String message,
  }) async {
    final clean = message.trim();
    if (clean.isEmpty) throw ArgumentError('empty-prize-reply');
    final accountKey = accountKeyForPhone(phone);
    if (accountKey.isEmpty) throw ArgumentError('prize-account-required');
    await _ensureOwnerSessionForAccountKey(accountKey);
    final ref = FirebaseFirestore.instance
        .collection('prize_winner_requests')
        .doc(_prizeWinnerRequestIdForPhone(phone));
    final snapshot = await ref.get();
    final data = snapshot.data();
    if (!snapshot.exists || data == null) {
      throw StateError('prize-request-not-found');
    }
    // Firebase anonymous UIDs can rotate across trusted sessions. The stable
    // DEDA account key is authoritative for the winner's own reply, matching
    // the sameAccount Firestore rule used elsewhere in the app.
    if ((data['accountKey'] ?? '').toString() != accountKey) {
      throw StateError('prize-request-owner-mismatch');
    }
    if ((data['status'] ?? '').toString() != 'needs_info') {
      throw StateError('prize-reply-not-requested');
    }
    await ref.update(<String, dynamic>{
      'status': 'reviewing',
      'userReply': clean,
      'userReplyAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  static Future<void> confirmPrizeReceivedByUser({
    required String phone,
  }) async {
    final accountKey = accountKeyForPhone(phone);
    if (accountKey.isEmpty) throw ArgumentError('prize-account-required');
    await _ensureOwnerSessionForAccountKey(accountKey);
    final ref = FirebaseFirestore.instance
        .collection('prize_winner_requests')
        .doc(_prizeWinnerRequestIdForPhone(phone));
    final snapshot = await ref.get();
    final data = snapshot.data();
    if (!snapshot.exists || data == null) {
      throw StateError('prize-request-not-found');
    }
    if ((data['accountKey'] ?? '').toString() != accountKey) {
      throw StateError('prize-request-owner-mismatch');
    }
    if ((data['status'] ?? '').toString() != 'prize_sent') {
      throw StateError('prize-not-awaiting-confirmation');
    }
    await ref.update(<String, dynamic>{
      'status': 'delivered',
      'winnerConfirmedAt': FieldValue.serverTimestamp(),
      'deliveredAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  static Stream<QuerySnapshot<Map<String, dynamic>>>
      prizeWinnerRequestsForAdmin() {
    return FirebaseFirestore.instance
        .collection('prize_winner_requests')
        .orderBy('updatedAt', descending: true)
        .limit(500)
        .snapshots();
  }

  static Future<void> updatePrizeWinnerRequestFromAdmin({
    required String requestId,
    required String status,
    String adminMessage = '',
    String prizeDetails = '',
  }) async {
    const allowed = <String>{
      'new',
      'reviewing',
      'needs_info',
      'approved',
      'prize_sent',
      'rejected',
    };
    if (!allowed.contains(status)) throw ArgumentError('invalid-prize-status');
    final actor = await currentAdminProfile();
    if (normalizeAdminRole(actor['role']) != 'general_manager') {
      throw StateError('general-manager-required');
    }
    final ref = FirebaseFirestore.instance
        .collection('prize_winner_requests')
        .doc(requestId);
    final snapshot = await ref.get();
    if (!snapshot.exists || snapshot.data() == null) {
      throw StateError('prize-request-not-found');
    }
    final before = snapshot.data()!;
    final beforeStatus = (before['status'] ?? 'new').toString();
    const transitions = <String, Set<String>>{
      'new': <String>{'new', 'reviewing', 'needs_info', 'approved', 'rejected'},
      'reviewing': <String>{'reviewing', 'needs_info', 'approved', 'rejected'},
      'needs_info': <String>{'needs_info', 'reviewing', 'approved', 'rejected'},
      'approved': <String>{'approved', 'prize_sent', 'rejected'},
      'prize_sent': <String>{'prize_sent'},
      'delivered': <String>{},
      'rejected': <String>{'rejected', 'reviewing'},
    };
    if (!(transitions[beforeStatus] ?? const <String>{}).contains(status)) {
      throw StateError('invalid-prize-status-transition');
    }
    if (status == 'prize_sent' && prizeDetails.trim().isEmpty) {
      throw ArgumentError('prize-details-required');
    }
    final update = <String, dynamic>{
      'status': status,
      'adminMessage': adminMessage.trim(),
      'prizeDetails': prizeDetails.trim(),
      'adminByUid': actor['uid'].toString(),
      'adminByName': actor['displayName'].toString(),
      'adminByRole': normalizeAdminRole(actor['role']),
      'adminUpdatedAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
      if (status == 'prize_sent' && beforeStatus != 'prize_sent')
        'prizeSentAt': FieldValue.serverTimestamp(),
    };
    await ref.update(update);
    await _writeAdminAudit(
      'prize_winner_status_changed',
      details: <String, dynamic>{
        'sourceCollection': 'prize_winner_requests',
        'sourceId': requestId,
        'targetAccountKey': before['accountKey'],
        'targetDedaId': before['dedaId'],
        'oldStatus': before['status'],
        'newStatus': status,
      },
    );
  }

  static String _newAdminInviteCode() {
    final random = Random.secure();
    return List<String>.generate(8, (_) => random.nextInt(10).toString())
        .join();
  }

  static Map<String, bool> _cleanAdminPermissions(
    Map<String, bool> permissions,
  ) {
    return <String, bool>{
      for (final entry in permissions.entries) entry.key: entry.value == true,
    };
  }

  static Future<Map<String, dynamic>> createAdminInvitation({
    required String displayName,
    required String email,
    required String role,
    required String department,
    required String governorate,
    required Map<String, bool> permissions,
    String phone = '',
  }) async {
    final actor = await currentAdminProfile();
    if (normalizeAdminRole(actor['role']) != 'general_manager') {
      throw StateError('general-manager-required');
    }

    final cleanName = displayName.trim();
    final cleanEmail = email.trim().toLowerCase();
    final cleanDepartment = department.trim();
    final cleanRole = normalizeAdminRole(role);
    final cleanGovernorate =
        cleanRole == 'province_agent' ? governorate.trim() : '';
    final needsDedicatedDedaPhone = cleanRole != 'general_manager';
    final entryAccountKey =
        needsDedicatedDedaPhone ? _adminEntryAccountKeyForPhone(phone) : '';

    if (cleanName.isEmpty) throw ArgumentError('display-name-required');
    if (cleanEmail.isEmpty || !cleanEmail.contains('@')) {
      throw ArgumentError('valid-email-required');
    }
    if (cleanDepartment.isEmpty) throw ArgumentError('department-required');
    if (!<String>{
      'general_manager',
      'deputy_manager',
      'employee',
      'province_agent',
    }.contains(cleanRole)) {
      throw ArgumentError('invalid-admin-role');
    }
    if (cleanRole == 'province_agent' && cleanGovernorate.isEmpty) {
      throw ArgumentError('governorate-required');
    }
    if (needsDedicatedDedaPhone && entryAccountKey.isEmpty) {
      throw ArgumentError('admin-deda-phone-required');
    }

    final firestore = FirebaseFirestore.instance;

    if (needsDedicatedDedaPhone) {
      final directory = await firestore
          .collection('deda_account_directory')
          .doc(entryAccountKey)
          .get();
      if (!directory.exists || directory.data()?['active'] != true) {
        throw StateError('deda-account-not-found');
      }
    }

    final existingAdmin = await firestore
        .collection('admins')
        .where('email', isEqualTo: cleanEmail)
        .limit(1)
        .get();
    if (existingAdmin.docs.isNotEmpty) {
      throw StateError('email-already-exists');
    }

    final existingInvite = await firestore
        .collection('admin_invites')
        .where('email', isEqualTo: cleanEmail)
        .limit(10)
        .get();
    if (existingInvite.docs.any((doc) {
      final status = (doc.data()['status'] ?? '').toString();
      return status == 'pending' || status == 'claimed';
    })) {
      throw StateError('invite-already-exists');
    }

    final inviteRef = firestore.collection('admin_invites').doc();
    final DocumentReference<Map<String, dynamic>>? entryAccessRef =
        needsDedicatedDedaPhone
            ? firestore.collection('admin_entry_access').doc(entryAccountKey)
            : null;
    final counterRef =
        firestore.collection('system_counters').doc('admin_members');
    final code = _newAdminInviteCode();
    final expiresAt = Timestamp.fromDate(
      DateTime.now().add(const Duration(days: 7)),
    );
    final cleanPermissions = _cleanAdminPermissions(permissions);

    late String adminId;
    await firestore.runTransaction((transaction) async {
      if (entryAccessRef != null) {
        final existingEntryAccess = await transaction.get(entryAccessRef);
        if (existingEntryAccess.exists &&
            existingEntryAccess.data()?['active'] == true) {
          throw StateError('admin-phone-already-authorized');
        }
      }

      final counter = await transaction.get(counterRef);
      final current = (counter.data()?['value'] as num?)?.toInt() ?? 0;
      final next = current + 1;
      adminId = 'DEDA-ADM-${next.toString().padLeft(6, '0')}';

      transaction.set(
        counterRef,
        <String, dynamic>{
          'value': next,
          'updatedAt': FieldValue.serverTimestamp(),
        },
        SetOptions(merge: true),
      );
      transaction.set(inviteRef, <String, dynamic>{
        'adminId': adminId,
        'displayName': cleanName,
        'email': cleanEmail,
        'phone': entryAccountKey,
        'department': cleanDepartment,
        'role': cleanRole,
        'governorate': cleanGovernorate,
        'permissions': cleanPermissions,
        'status': 'pending',
        'activationCode': code,
        'createdByUid': actor['uid'].toString(),
        'createdByName': actor['displayName'].toString(),
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
        'expiresAt': expiresAt,
      });
      if (entryAccessRef != null) {
        transaction.set(entryAccessRef, <String, dynamic>{
          'accountKey': entryAccountKey,
          'phone': adminEntryPhoneDisplay(entryAccountKey),
          'accessType': 'member',
          'allowedRole': cleanRole,
          'allowedAdminEmail': cleanEmail,
          'inviteId': inviteRef.id,
          'adminUid': '',
          'adminId': adminId,
          'status': 'invited',
          'active': true,
          'expiresAt': expiresAt,
          'createdAt': FieldValue.serverTimestamp(),
          'updatedAt': FieldValue.serverTimestamp(),
          'managedByUid': actor['uid'].toString(),
          'managedByName': actor['displayName'].toString(),
        });
      }
    });

    await _writeAdminAudit(
      'admin_invite_created',
      details: <String, dynamic>{
        'inviteId': inviteRef.id,
        'targetAdminId': adminId,
        'targetAdminName': cleanName,
        'targetAdminRole': cleanRole,
        'targetEmail': cleanEmail,
        'targetGovernorate':
            cleanRole == 'province_agent' ? cleanGovernorate : null,
      },
    );

    return <String, dynamic>{
      'inviteId': inviteRef.id,
      'adminId': adminId,
      'email': cleanEmail,
      'activationCode': code,
      'expiresAt': expiresAt,
    };
  }

  static Future<void> markAdminInvitationShared({
    required String inviteId,
    required String channel,
  }) async {
    final actor = await currentAdminProfile();
    if (normalizeAdminRole(actor['role']) != 'general_manager') {
      throw StateError('general-manager-required');
    }
    final cleanId = inviteId.trim();
    if (cleanId.isEmpty) return;
    final ref =
        FirebaseFirestore.instance.collection('admin_invites').doc(cleanId);
    final snapshot = await ref.get();
    if (!snapshot.exists) return;
    final data = snapshot.data() ?? <String, dynamic>{};
    await ref.set(<String, dynamic>{
      'lastSharedAt': FieldValue.serverTimestamp(),
      'lastSharedByUid': actor['uid'].toString(),
      'lastSharedByName': actor['displayName'].toString(),
      'lastShareChannel': channel.trim(),
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
    await _writeAdminAudit(
      'admin_invite_shared',
      details: <String, dynamic>{
        'inviteId': cleanId,
        'targetAdminId': data['adminId'],
        'targetAdminName': data['displayName'],
        'targetEmail': data['email'],
        'channel': channel.trim(),
      },
    );
  }

  static Future<void> cancelAdminInvitation(String inviteId) async {
    final actor = await currentAdminProfile();
    if (normalizeAdminRole(actor['role']) != 'general_manager') {
      throw StateError('general-manager-required');
    }
    final ref =
        FirebaseFirestore.instance.collection('admin_invites').doc(inviteId);
    final snapshot = await ref.get();
    if (!snapshot.exists) return;
    final data = snapshot.data() ?? <String, dynamic>{};
    await _writeAdminAudit(
      'admin_invite_cancelled',
      details: <String, dynamic>{
        'inviteId': inviteId,
        'targetAdminId': data['adminId'],
        'targetAdminName': data['displayName'],
        'targetEmail': data['email'],
      },
    );
    final entryAccountKey = _adminEntryAccountKeyForPhone(
      (data['phone'] ?? '').toString(),
    );
    if (entryAccountKey.isNotEmpty) {
      final entryRef = FirebaseFirestore.instance
          .collection('admin_entry_access')
          .doc(entryAccountKey);
      final entrySnapshot = await entryRef.get();
      if (entrySnapshot.exists &&
          (entrySnapshot.data()?['inviteId'] ?? '').toString() == inviteId) {
        await entryRef.delete();
      }
    }
    await ref.delete();
  }

  static Future<Map<String, dynamic>> activateAdminInvitation({
    required String inviteId,
    required String activationCode,
    required String email,
    required String password,
  }) async {
    if (!isReady) throw StateError('firebase-not-ready');
    final cleanInviteId = inviteId.trim();
    final cleanCode = activationCode.trim();
    final cleanEmail = email.trim().toLowerCase();
    if (cleanInviteId.isEmpty) throw ArgumentError('invite-id-required');
    if (!RegExp(r'^\d{8}$').hasMatch(cleanCode)) {
      throw ArgumentError('invalid-invite-code');
    }
    if (cleanEmail.isEmpty || !cleanEmail.contains('@')) {
      throw ArgumentError('valid-email-required');
    }
    if (password.length < 8) throw ArgumentError('weak-password');

    final auth = FirebaseAuth.instance;
    UserCredential credential;
    try {
      credential = await auth.createUserWithEmailAndPassword(
        email: cleanEmail,
        password: password,
      );
    } catch (error) {
      rethrow;
    }

    final user = credential.user;
    if (user == null) {
      await auth.signOut();
      throw StateError('admin-account-create-failed');
    }

    final firestore = FirebaseFirestore.instance;
    final inviteRef = firestore.collection('admin_invites').doc(cleanInviteId);
    final adminRef = firestore.collection('admins').doc(user.uid);
    var claimed = false;
    var adminCreated = false;

    try {
      await inviteRef.update(<String, dynamic>{
        'status': 'claimed',
        'claimedUid': user.uid,
        'claimCode': cleanCode,
        'claimedAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
      claimed = true;

      final inviteSnapshot = await inviteRef.get();
      if (!inviteSnapshot.exists) throw StateError('invite-not-found');
      final invite = inviteSnapshot.data() ?? <String, dynamic>{};
      if ((invite['status'] ?? '').toString() != 'claimed' ||
          (invite['claimedUid'] ?? '').toString() != user.uid) {
        throw StateError('invite-not-claimed');
      }
      if ((invite['email'] ?? '').toString().trim().toLowerCase() !=
          cleanEmail) {
        throw StateError('invite-email-mismatch');
      }

      final expiresAt = invite['expiresAt'];
      if (expiresAt is Timestamp &&
          expiresAt.toDate().isBefore(DateTime.now())) {
        throw StateError('invite-expired');
      }

      final role = normalizeAdminRole(invite['role']);
      final permissions = invite['permissions'] is Map
          ? Map<String, dynamic>.from(invite['permissions'] as Map)
          : <String, dynamic>{};

      await adminRef.set(<String, dynamic>{
        'adminId': (invite['adminId'] ?? '').toString(),
        'displayName': (invite['displayName'] ?? '').toString(),
        'email': cleanEmail,
        'phone': (invite['phone'] ?? '').toString(),
        'department': (invite['department'] ?? '').toString(),
        'role': role,
        'governorate': role == 'province_agent'
            ? (invite['governorate'] ?? '').toString()
            : '',
        'status': 'active',
        'active': true,
        'permissions': permissions,
        'mustChangePassword': false,
        'inviteId': cleanInviteId,
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
        'createdByUid': (invite['createdByUid'] ?? '').toString(),
        'createdByName': (invite['createdByName'] ?? '').toString(),
        'permissionsUpdatedAt': FieldValue.serverTimestamp(),
        'permissionsUpdatedByUid': (invite['createdByUid'] ?? '').toString(),
        'permissionsUpdatedByName': (invite['createdByName'] ?? '').toString(),
        'lastSeenAt': FieldValue.serverTimestamp(),
        'lastLoginAt': FieldValue.serverTimestamp(),
        'firstLoginCompletedAt': FieldValue.serverTimestamp(),
      });
      adminCreated = true;

      try {
        await inviteRef.update(<String, dynamic>{
          'status': 'completed',
          'acceptedAt': FieldValue.serverTimestamp(),
          'updatedAt': FieldValue.serverTimestamp(),
          'activationCode': FieldValue.delete(),
          'claimCode': FieldValue.delete(),
        });
      } catch (_) {
        // The admin record is already secure and usable. Invite cleanup can
        // be completed later by the general manager if the network drops here.
      }

      try {
        await syncCurrentAdminEntryAccessForDedaAccount(
          phone: (invite['phone'] ?? '').toString(),
        );
      } catch (_) {}
      try {
        await registerAdminNotifications();
      } catch (_) {}
      await _writeAdminAudit(
        'admin_invite_accepted',
        details: <String, dynamic>{
          'inviteId': cleanInviteId,
          'targetAdminId': invite['adminId'],
          'targetAdminName': invite['displayName'],
          'targetAdminRole': role,
        },
      );
      return currentAdminProfile();
    } catch (error) {
      if (!adminCreated) {
        if (claimed) {
          try {
            await inviteRef.update(<String, dynamic>{
              'status': 'pending',
              'claimedUid': FieldValue.delete(),
              'claimCode': FieldValue.delete(),
              'claimedAt': FieldValue.delete(),
              'updatedAt': FieldValue.serverTimestamp(),
            });
          } catch (_) {}
        }
        try {
          await user.delete();
        } catch (_) {}
        try {
          await auth.signOut();
        } catch (_) {}
      }
      rethrow;
    }
  }

  static Future<void> updateAdminMember({
    required String uid,
    required String displayName,
    required String role,
    required String department,
    required String governorate,
    required String status,
    required Map<String, bool> permissions,
    required String reason,
    String phone = '',
  }) async {
    final actor = await currentAdminProfile();
    if (normalizeAdminRole(actor['role']) != 'general_manager') {
      throw StateError('general-manager-required');
    }
    if (reason.trim().isEmpty) throw ArgumentError('reason-required');

    final ref = FirebaseFirestore.instance.collection('admins').doc(uid);
    final snapshot = await ref.get();
    if (!snapshot.exists) throw StateError('admin-member-not-found');
    final current = snapshot.data() ?? <String, dynamic>{};

    final newRole = normalizeAdminRole(role);
    final newStatus = status.trim().toLowerCase();
    if (!<String>{
      'general_manager',
      'deputy_manager',
      'employee',
      'province_agent',
    }.contains(newRole)) {
      throw ArgumentError('invalid-admin-role');
    }
    if (!<String>{
      'active',
      'temporarily_stopped',
      'disabled',
    }.contains(newStatus)) {
      throw ArgumentError('invalid-admin-status');
    }
    if (displayName.trim().isEmpty) {
      throw ArgumentError('display-name-required');
    }
    if (department.trim().isEmpty) {
      throw ArgumentError('department-required');
    }
    if (newRole == 'province_agent' && governorate.trim().isEmpty) {
      throw ArgumentError('governorate-required');
    }

    if (uid == actor['uid'].toString()) {
      final oldRole = normalizeAdminRole(current['role']);
      final oldStatus = normalizeAdminStatus(current);
      if (newRole != oldRole || newStatus != oldStatus) {
        throw StateError('cannot-change-current-admin-access');
      }
    }

    final cleanPermissions = _cleanAdminPermissions(permissions);
    await ref.update(<String, dynamic>{
      'displayName': displayName.trim(),
      'phone': phone.trim(),
      'department': department.trim(),
      'role': newRole,
      'governorate': newRole == 'province_agent' ? governorate.trim() : '',
      'status': newStatus,
      'active': newStatus == 'active',
      'permissions': cleanPermissions,
      'updatedAt': FieldValue.serverTimestamp(),
      'updatedByUid': actor['uid'].toString(),
      'updatedByName': actor['displayName'].toString(),
      'permissionsUpdatedAt': FieldValue.serverTimestamp(),
      'permissionsUpdatedByUid': actor['uid'].toString(),
      'permissionsUpdatedByName': actor['displayName'].toString(),
      'statusReason': reason.trim(),
      'statusUpdatedAt': FieldValue.serverTimestamp(),
      'statusUpdatedByUid': actor['uid'].toString(),
      'statusUpdatedByName': actor['displayName'].toString(),
    });

    // Keep the protected administration-entry registry in sync with the
    // member record. Older members can predate admin_entry_access, so saving
    // their details once from the general-manager screen also repairs the
    // missing gateway without deleting/re-inviting the member.
    final oldEntryAccountKey =
        _adminEntryAccountKeyForPhone((current['phone'] ?? '').toString());
    final newEntryAccountKey = _adminEntryAccountKeyForPhone(phone);
    final memberEmail =
        (current['email'] ?? '').toString().trim().toLowerCase();

    if (newRole == 'general_manager') {
      // General-manager entry phones are managed only through the dedicated
      // gateway list. Remove an old member gateway when a role is promoted.
      if (oldEntryAccountKey.isNotEmpty) {
        final oldEntryRef = FirebaseFirestore.instance
            .collection('admin_entry_access')
            .doc(oldEntryAccountKey);
        final oldEntry = await oldEntryRef.get();
        final oldData = oldEntry.data();
        final belongsToMember = oldEntry.exists &&
            oldData != null &&
            (oldData['accessType'] ?? '').toString() == 'member' &&
            ((oldData['adminUid'] ?? '').toString() == uid ||
                (oldData['adminId'] ?? '').toString() ==
                    (current['adminId'] ?? '').toString() ||
                ((oldData['allowedAdminEmail'] ?? oldData['email'] ?? '')
                        .toString()
                        .trim()
                        .toLowerCase() ==
                    memberEmail));
        if (belongsToMember) {
          await oldEntryRef.delete();
        }
      }
    } else if (newEntryAccountKey.isNotEmpty) {
      final directory = await FirebaseFirestore.instance
          .collection('deda_account_directory')
          .doc(newEntryAccountKey)
          .get();
      if (!directory.exists || directory.data()?['active'] != true) {
        throw StateError('deda-account-not-found');
      }

      if (oldEntryAccountKey.isNotEmpty &&
          oldEntryAccountKey != newEntryAccountKey) {
        final oldEntryRef = FirebaseFirestore.instance
            .collection('admin_entry_access')
            .doc(oldEntryAccountKey);
        final oldEntry = await oldEntryRef.get();
        final oldData = oldEntry.data();
        final belongsToMember = oldEntry.exists &&
            oldData != null &&
            (oldData['accessType'] ?? '').toString() == 'member' &&
            ((oldData['adminUid'] ?? '').toString() == uid ||
                (oldData['adminId'] ?? '').toString() ==
                    (current['adminId'] ?? '').toString() ||
                ((oldData['allowedAdminEmail'] ?? oldData['email'] ?? '')
                        .toString()
                        .trim()
                        .toLowerCase() ==
                    memberEmail));
        if (belongsToMember) {
          await oldEntryRef.delete();
        }
      }

      await FirebaseFirestore.instance
          .collection('admin_entry_access')
          .doc(newEntryAccountKey)
          .set(<String, dynamic>{
        'accountKey': newEntryAccountKey,
        'phone': adminEntryPhoneDisplay(newEntryAccountKey),
        'accessType': 'member',
        'allowedRole': newRole,
        'allowedAdminEmail': memberEmail,
        'adminUid': uid,
        'adminId': (current['adminId'] ?? '').toString(),
        'status': newStatus,
        'active': newStatus == 'active',
        'updatedAt': FieldValue.serverTimestamp(),
        'managedByUid': actor['uid'].toString(),
        'managedByName': actor['displayName'].toString(),
      }, SetOptions(merge: true));
    }

    await _writeAdminAudit(
      'admin_member_updated',
      details: <String, dynamic>{
        'targetAdminUid': uid,
        'targetAdminId': current['adminId'],
        'targetAdminName': displayName.trim(),
        'oldRole': normalizeAdminRole(current['role']),
        'newRole': newRole,
        'oldStatus': normalizeAdminStatus(current),
        'newStatus': newStatus,
        'reason': reason.trim(),
      },
    );
  }

  static Future<void> revokeAdminMemberSessions({
    required String uid,
    required String reason,
  }) async {
    final actor = await currentAdminProfile();
    if (normalizeAdminRole(actor['role']) != 'general_manager') {
      throw StateError('general-manager-required');
    }
    if (uid == actor['uid'].toString()) {
      throw StateError('cannot-stop-current-session');
    }
    if (reason.trim().isEmpty) throw ArgumentError('reason-required');

    final ref = FirebaseFirestore.instance.collection('admins').doc(uid);
    final snapshot = await ref.get();
    if (!snapshot.exists) throw StateError('admin-member-not-found');
    final data = snapshot.data() ?? <String, dynamic>{};

    await ref.update(<String, dynamic>{
      'status': 'temporarily_stopped',
      'active': false,
      'updatedAt': FieldValue.serverTimestamp(),
      'statusReason': reason.trim(),
      'statusUpdatedAt': FieldValue.serverTimestamp(),
      'statusUpdatedByUid': actor['uid'].toString(),
      'statusUpdatedByName': actor['displayName'].toString(),
    });
    await _writeAdminAudit(
      'admin_access_suspended',
      details: <String, dynamic>{
        'targetAdminUid': uid,
        'targetAdminId': data['adminId'],
        'targetAdminName': data['displayName'] ?? data['name'],
        'reason': reason.trim(),
      },
    );
  }

  static Future<void> sendAdminPasswordReset({
    required String email,
  }) async {
    final actor = await currentAdminProfile();
    if (normalizeAdminRole(actor['role']) != 'general_manager') {
      throw StateError('general-manager-required');
    }
    final cleanEmail = email.trim().toLowerCase();
    if (cleanEmail.isEmpty) throw ArgumentError('valid-email-required');
    await FirebaseAuth.instance.sendPasswordResetEmail(email: cleanEmail);
    await _writeAdminAudit(
      'admin_password_reset_sent',
      details: <String, dynamic>{'targetEmail': cleanEmail},
    );
  }

  static Future<void> deleteAdminMember({
    required String uid,
    required String reason,
  }) async {
    final actor = await currentAdminProfile();
    if (normalizeAdminRole(actor['role']) != 'general_manager') {
      throw StateError('general-manager-required');
    }
    if (uid == actor['uid'].toString()) {
      throw StateError('cannot-delete-current-admin');
    }
    if (reason.trim().isEmpty) throw ArgumentError('reason-required');

    final ref = FirebaseFirestore.instance.collection('admins').doc(uid);
    final snapshot = await ref.get();
    if (!snapshot.exists) return;
    final data = snapshot.data() ?? <String, dynamic>{};
    await _writeAdminAudit(
      'admin_member_access_removed',
      details: <String, dynamic>{
        'targetAdminUid': uid,
        'targetAdminId': data['adminId'],
        'targetAdminName': data['displayName'] ?? data['name'],
        'targetAdminRole': normalizeAdminRole(data['role']),
        'reason': reason.trim(),
      },
    );
    await ref.delete();
  }

  static Future<void> changeCurrentAdminPassword(String newPassword) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null || user.isAnonymous) {
      throw StateError('admin-not-signed-in');
    }
    await user.updatePassword(newPassword);
    await FirebaseFirestore.instance.collection('admins').doc(user.uid).update({
      'mustChangePassword': false,
      'firstLoginCompletedAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
    _clearAdminProfileCache();
  }

  // Administration member password recovery. Requests are opened only from
  // the already-authorized DEDA phone. The general manager decides, while a
  // callable Cloud Function performs the sensitive Firebase Auth password
  // update after the member supplies the six-digit recovery code.
  static Future<String> requestAdminPasswordRecovery({
    required String phone,
    required String fullName,
    required String email,
  }) async {
    if (!isReady) throw StateError('firebase-not-ready');
    final accountKey = _adminEntryAccountKeyForPhone(phone);
    final cleanName = fullName.trim().replaceAll(RegExp(r'\s+'), ' ');
    final cleanEmail = email.trim().toLowerCase();
    if (accountKey.isEmpty) throw ArgumentError('recovery-account-missing');
    if (cleanName.length < 2) throw ArgumentError('recovery-name-required');
    if (cleanEmail.isEmpty || !cleanEmail.contains('@')) {
      throw ArgumentError('recovery-email-required');
    }

    final auth = FirebaseAuth.instance;
    var current = auth.currentUser;
    if (current == null || !current.isAnonymous) {
      try {
        await DedaPinAuth.restoreTrustedSessionForAccountKey(accountKey);
      } catch (_) {}
      current = auth.currentUser;
    }
    if (current == null) throw StateError('deda-session-required');

    final firestore = FirebaseFirestore.instance;
    final accessRef =
        firestore.collection('admin_entry_access').doc(accountKey);
    final accessSnapshot = await accessRef.get();
    final access = accessSnapshot.data();
    if (!accessSnapshot.exists ||
        access == null ||
        access['active'] != true ||
        (access['status'] ?? '').toString() != 'active' ||
        (access['accessType'] ?? '').toString() != 'member') {
      throw StateError('admin-recovery-not-authorized');
    }

    final allowedEmail =
        (access['allowedAdminEmail'] ?? '').toString().trim().toLowerCase();
    final targetAdminUid = (access['adminUid'] ?? '').toString().trim();
    final targetAdminId = (access['adminId'] ?? '').toString().trim();
    final targetRole = normalizeAdminRole(access['allowedRole']);
    if (allowedEmail.isEmpty ||
        allowedEmail != cleanEmail ||
        targetAdminUid.isEmpty ||
        targetRole == 'general_manager') {
      throw StateError('admin-recovery-identity-mismatch');
    }

    // Reuse an unresolved request instead of creating duplicates when the
    // member taps the action twice because of a slow connection.
    try {
      final existing = await firestore
          .collection('admin_recovery_requests')
          .where('accountKey', isEqualTo: accountKey)
          .limit(20)
          .get();
      for (final doc in existing.docs) {
        final data = doc.data();
        final status = (data['status'] ?? '').toString();
        if (status == 'new' || status == 'approved') {
          return doc.id;
        }
        if (status == 'ready') {
          final expiresAt = data['recoveryPinExpiresAt'];
          if (expiresAt is Timestamp &&
              expiresAt.toDate().isAfter(DateTime.now())) {
            return doc.id;
          }
        }
      }
    } catch (_) {
      // Creation below remains authoritative if the duplicate check cannot run.
    }

    final ref = firestore.collection('admin_recovery_requests').doc();
    await ref.set(<String, dynamic>{
      'requesterUid': current.uid,
      'accountKey': accountKey,
      'phone': adminEntryPhoneDisplay(accountKey),
      'fullName': cleanName,
      'email': cleanEmail,
      'targetAdminUid': targetAdminUid,
      'targetAdminId': targetAdminId,
      'targetRole': targetRole,
      'status': 'new',
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
    return ref.id;
  }

  static Stream<Map<String, dynamic>?> adminRecoveryRequestStream(
    String requestId,
  ) {
    final cleanId = requestId.trim();
    if (cleanId.isEmpty || !isReady) {
      return Stream<Map<String, dynamic>?>.value(null);
    }
    return FirebaseFirestore.instance
        .collection('admin_recovery_requests')
        .doc(cleanId)
        .snapshots()
        .map((snapshot) {
      final data = snapshot.data();
      if (!snapshot.exists || data == null) return null;
      return <String, dynamic>{'id': snapshot.id, ...data};
    });
  }

  static Stream<int> pendingAdminRecoveryCountStream() {
    if (!isReady) return Stream<int>.value(0);
    return FirebaseFirestore.instance
        .collection('admin_recovery_requests')
        .where('status', isEqualTo: 'new')
        .snapshots()
        .map((snapshot) => snapshot.docs.length);
  }

  static Stream<List<Map<String, dynamic>>> adminRecoveryRequestsStream() {
    if (!isReady) {
      return Stream<List<Map<String, dynamic>>>.value(const []);
    }
    return FirebaseFirestore.instance
        .collection('admin_recovery_requests')
        .orderBy('createdAt', descending: true)
        .limit(100)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => <String, dynamic>{'id': doc.id, ...doc.data()})
            .toList());
  }

  static Future<void> decideAdminPasswordRecovery({
    required String requestId,
    required bool approve,
    String rejectionReason = '',
  }) async {
    final actor = await currentAdminProfile(forceRefresh: true);
    if (normalizeAdminRole(actor['role']) != 'general_manager') {
      throw StateError('general-manager-required');
    }

    final cleanId = requestId.trim();
    if (cleanId.isEmpty) throw ArgumentError('request-id-required');
    final reason = rejectionReason.trim();
    if (!approve && reason.isEmpty) {
      throw ArgumentError('rejection-reason-required');
    }

    final ref = FirebaseFirestore.instance
        .collection('admin_recovery_requests')
        .doc(cleanId);
    final snapshot = await ref.get();
    if (!snapshot.exists) throw StateError('recovery-request-not-found');
    final current = snapshot.data() ?? <String, dynamic>{};
    if ((current['status'] ?? '').toString() != 'new') {
      throw StateError('recovery-request-already-decided');
    }

    if (!approve) {
      await ref.update(<String, dynamic>{
        'status': 'rejected',
        'decisionByUid': actor['uid'].toString(),
        'decisionByName': actor['displayName'].toString(),
        'decisionAt': FieldValue.serverTimestamp(),
        'rejectionReason': reason,
        'updatedAt': FieldValue.serverTimestamp(),
      });
      return;
    }

    final pin = (100000 + Random.secure().nextInt(900000)).toString();
    final expiresAt = Timestamp.fromDate(
      DateTime.now().add(const Duration(minutes: 30)),
    );
    await ref.update(<String, dynamic>{
      'status': 'ready',
      'decisionByUid': actor['uid'].toString(),
      'decisionByName': actor['displayName'].toString(),
      'decisionAt': FieldValue.serverTimestamp(),
      'rejectionReason': '',
      'recoveryPin': pin,
      'recoveryPinIssuedAt': FieldValue.serverTimestamp(),
      'recoveryPinExpiresAt': expiresAt,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  static Future<void> completeAdminPasswordRecovery({
    required String requestId,
    required String recoveryCode,
  }) async {
    if (!isReady) throw StateError('firebase-not-ready');
    final cleanId = requestId.trim();
    final cleanCode = recoveryCode.trim();
    if (cleanId.isEmpty) throw ArgumentError('request-id-required');
    if (!RegExp(r'^\d{6}$').hasMatch(cleanCode)) {
      throw ArgumentError('invalid-recovery-code');
    }

    final ref = FirebaseFirestore.instance
        .collection('admin_recovery_requests')
        .doc(cleanId);
    final snapshot = await ref.get();
    if (!snapshot.exists) throw StateError('recovery-request-not-found');
    final data = snapshot.data() ?? <String, dynamic>{};
    if ((data['status'] ?? '').toString() != 'ready') {
      throw StateError('recovery-request-not-ready');
    }

    final currentUser = FirebaseAuth.instance.currentUser;
    final accountKey = (data['accountKey'] ?? '').toString().trim();
    if (currentUser == null || accountKey.isEmpty) {
      throw StateError('deda-session-required');
    }
    final session = await FirebaseFirestore.instance
        .collection('deda_sessions')
        .doc(currentUser.uid)
        .get();
    if (!session.exists ||
        (session.data()?['accountKey'] ?? '').toString() != accountKey) {
      throw StateError('recovery-account-mismatch');
    }

    final expiresAt = data['recoveryPinExpiresAt'];
    if (expiresAt is! Timestamp ||
        !expiresAt.toDate().isAfter(DateTime.now())) {
      throw StateError('recovery-code-expired');
    }
    if ((data['recoveryPin'] ?? '').toString() != cleanCode) {
      throw StateError('invalid-recovery-code');
    }

    final email = (data['email'] ?? '').toString().trim().toLowerCase();
    if (email.isEmpty) throw StateError('recovery-email-missing');
    await FirebaseAuth.instance.sendPasswordResetEmail(email: email);

    try {
      await ref.update(<String, dynamic>{
        'status': 'reset_link_sent',
        'resetLinkSentAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
    } catch (_) {
      // The secure reset email was already sent; status bookkeeping must not
      // turn that successful operation into a failure for the member.
    }
  }

  static Future<void> deleteRoadHazardAsAdmin({
    required String id,
    required String reason,
  }) async {
    final actor = await _adminIdentity();
    final ref = FirebaseFirestore.instance.collection('road_hazards').doc(id);
    final snapshot = await ref.get();
    if (!snapshot.exists) return;
    await ref.delete();
    await _writeAdminAudit(
      'road_hazard_deleted',
      details: <String, dynamic>{
        'targetId': id,
        'reason': reason.trim(),
        'hazardType': snapshot.data()?['type'],
        'adminUid': actor['uid'],
      },
    );
  }

  static Future<void> signOutAdmin() async {
    try {
      await _writeAdminAudit('admin_signed_out');
    } catch (_) {}
    _clearAdminProfileCache();
    await FirebaseAuth.instance.signOut();
  }

  // DEDA in-app location sharing v1.
  static const String _shareAlphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

  // DEDA accounts use Iraqi mobile numbers. The final nine digits contain
  // exactly 1,000,000,000 possible values, while six base-32 characters hold
  // 1,073,741,824 values. A modular offset therefore gives every valid phone
  // a collision-free six-character public code without exposing the phone.
  static String _shareCodeForPhone(String phone, int offset) {
    final key = accountKeyForPhone(phone);
    if (key.length < 9) return '';
    final tail = key.substring(key.length - 9);
    final raw = int.tryParse(tail);
    if (raw == null) return '';
    var value = (raw + offset) % 1000000000;
    final chars = List<String>.filled(6, _shareAlphabet[0]);
    for (var index = 5; index >= 0; index--) {
      chars[index] = _shareAlphabet[value % 32];
      value ~/= 32;
    }
    return chars.join();
  }

  static String personalShareIdForPhone(String phone) {
    final code = _shareCodeForPhone(phone, 314159265);
    if (code.isEmpty) return '';
    return '@DEDA-$code';
  }

  static String placeShareIdForPhone(String phone) {
    final code = _shareCodeForPhone(phone, 271828182);
    if (code.isEmpty) return '';
    return '@DEDA-P-$code';
  }

  static String normalizeSharePublicId(String value) {
    var id = value.trim().toUpperCase().replaceAll(' ', '');
    if (id.isEmpty) return '';
    if (!id.startsWith('@')) id = '@$id';
    return id;
  }

  static bool isValidPersonalShareId(String value) {
    final id = normalizeSharePublicId(value);
    return RegExp(r'^@DEDA-[A-Z2-9]{6}$').hasMatch(id);
  }

  // STAGE64_CROSS_DEVICE_OWNER_RECOVERY: read-only. The old installation
  // cached a place ID in SharedPreferences; a new phone has no such ID.
  // NEVER infer ownership merely from an entered name/phone, a public map
  // result, or old ownerUid. Require the authenticated DEDA PIN/trusted
  // session accountKey and leave the published document immutable.
  static Future<Map<String, dynamic>?> recoverPublishedPlaceForSignedInOwner({
    required String expectedAccountKey,
  }) async {
    final expected = expectedAccountKey.trim();
    final user = FirebaseAuth.instance.currentUser;
    if (!isReady || expected.isEmpty || user == null || !user.isAnonymous) {
      throw StateError('owner-recovery-login-required');
    }

    final session = await FirebaseFirestore.instance
        .collection('deda_sessions')
        .doc(user.uid)
        .get();
    final trustedKey = (session.data()?['accountKey'] ?? '').toString().trim();
    if (!session.exists || trustedKey.isEmpty || trustedKey != expected) {
      throw StateError('owner-recovery-session-mismatch');
    }

    // Require an explicit published==true filter so Firestore public-read
    // rules cannot accidentally include unpublished/hidden private records.
    // Index readiness must be checked against the real deployed rules/indexes.
    final matches = await FirebaseFirestore.instance
        .collection('published_places')
        .where('accountKey', isEqualTo: trustedKey)
        .where('published', isEqualTo: true)
        .limit(2)
        .get();
    if (FirebaseAuth.instance.currentUser?.uid != user.uid) {
      throw StateError('owner-recovery-session-changed');
    }
    if (matches.docs.length > 1) {
      // Never guess between multiple places or overwrite ownerUid.
      throw StateError('owner-recovery-ambiguous');
    }
    if (matches.docs.isEmpty) return null;
    final place = matches.docs.single;
    if (place.data()['accountKey']?.toString().trim() != trustedKey ||
        place.data()['published'] != true) {
      throw StateError('owner-recovery-invalid-record');
    }
    return <String, dynamic>{'id': place.id, ...place.data()};
  }

  static Future<Map<String, dynamic>?> currentOwnerPublishedPlace(
    String phone,
  ) async {
    final accountKey = accountKeyForPhone(phone);
    if (accountKey.isEmpty) return null;
    final all = await publishedPlaces();
    for (final item in all) {
      if ((item['accountKey'] ?? '').toString() == accountKey &&
          item['published'] == true) {
        return item;
      }
    }
    return null;
  }

  static Future<Map<String, String>> ensureLocationShareIdentity({
    required String name,
    required String phone,
    required bool hasApprovedPlace,
    String accountType = 'user',
    String placeName = '',
  }) async {
    final accountKey = accountKeyForPhone(phone);
    if (accountKey.isEmpty) throw StateError('share-account-missing');

    // A locally remembered DEDA login can outlive Firebase's anonymous
    // session. Restore the trusted DEDA session for this installation before
    // writing the public sharing identity, otherwise Firestore correctly
    // rejects the share-ID registration.
    final user = await _ensureOwnerSessionForAccountKey(accountKey);

    final personalId = personalShareIdForPhone(phone);
    final placeId = hasApprovedPlace ? placeShareIdForPhone(phone) : '';
    final firestore = FirebaseFirestore.instance;

    // The stable DEDA ID is derived from the phone and never regenerated here.
    // After an admin session or an app/auth refresh Firebase may give the app a
    // new anonymous UID. In that case users/{uid} does not exist yet, so writing
    // only the share fields is rejected by the Firestore create rule because
    // accountKey is missing. Seed the complete public-user identity first while
    // preserving the same deterministic DEDA ID.
    final userRef = firestore.collection('users').doc(user.uid);
    final userSnapshot = await userRef.get();
    final cleanAccountType = accountType.trim();
    await userRef.set({
      'name': name.trim(),
      'phone': phone.trim(),
      'accountKey': accountKey,
      'accountType': cleanAccountType.isEmpty ? 'user' : cleanAccountType,
      'authMethod': 'deda_pin_firestore_v1',
      'sharePersonalId': personalId,
      'sharePlaceId': placeId,
      if (!userSnapshot.exists) 'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
      'lastSeenAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));

    Future<void> claim({
      required String publicId,
      required String kind,
      required String displayName,
    }) async {
      if (publicId.isEmpty) return;
      final ref = firestore.collection('deda_share_ids').doc(publicId);
      final existing = await ref.get();
      if (existing.exists) return;
      await ref.set({
        'publicId': publicId,
        'kind': kind,
        'displayName': displayName.trim(),
        'ownerUid': user.uid,
        'active': true,
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
    }

    await claim(
      publicId: personalId,
      kind: 'personal',
      displayName: name,
    );
    if (placeId.isNotEmpty) {
      await claim(
        publicId: placeId,
        kind: 'place',
        displayName: placeName.isEmpty ? name : placeName,
      );
    }

    return <String, String>{
      'personalId': personalId,
      'placeId': placeId,
    };
  }

  static Future<Map<String, dynamic>?> locationShareIdInfo(String value) async {
    final id = normalizeSharePublicId(value);
    if (id.isEmpty || !isReady) return null;
    final snapshot = await FirebaseFirestore.instance
        .collection('deda_share_ids')
        .doc(id)
        .get();
    final data = snapshot.data();
    if (!snapshot.exists || data == null || data['active'] != true) return null;
    return <String, dynamic>{'id': snapshot.id, ...data};
  }

  static Future<String> createLocationShare({
    required String recipientPublicId,
    required String senderPublicId,
    required String senderName,
    required String shareType,
    required double latitude,
    required double longitude,
    required int durationMinutes,
    String placeName = '',
    String placeDocumentId = '',
  }) async {
    if (!isReady) throw StateError('firebase-not-ready');
    if (durationMinutes != 15 &&
        durationMinutes != 30 &&
        durationMinutes != 60) {
      throw ArgumentError('invalid-share-duration');
    }
    if (shareType != 'current' && shareType != 'place') {
      throw ArgumentError('invalid-share-type');
    }

    // DEDA_QA32_SHARE_TO_VERIFIED_ACTIVE_PREMIUM_ALIAS_CANONICAL_ROUTE
    // Canonical original IDs always take precedence over six-letter aliases.
    final requested = normalizeSharePublicId(recipientPublicId);
    final senderId = normalizeSharePublicId(senderPublicId);
    if (!RegExp(r'^@DEDA-[A-Z0-9]{4,12}$').hasMatch(requested)) {
      throw ArgumentError('invalid-recipient-share-id');
    }
    var recipientId = requested;
    var recipient = isValidPersonalShareId(recipientId)
        ? await locationShareIdInfo(recipientId)
        : null;
    if (recipient == null ||
        (recipient['kind'] ?? '').toString() != 'personal') {
      final verified = await DedaQa32PublicRecipientResolver.resolveActiveAlias(
        requested,
      );
      if (verified == null || !isValidPersonalShareId(verified)) {
        throw StateError('recipient-share-id-not-found');
      }
      recipientId = verified;
      recipient = await locationShareIdInfo(recipientId);
    }
    if (recipient == null ||
        (recipient['kind'] ?? '').toString() != 'personal') {
      throw StateError('recipient-share-id-not-found');
    }

    final user = await _ensurePublicUser();
    final firestore = FirebaseFirestore.instance;
    final ref = firestore.collection('deda_location_shares').doc();
    final expiresAt = DateTime.now().add(Duration(minutes: durationMinutes));

    await ref.set({
      'senderUid': user.uid,
      'senderPublicId': senderId,
      'senderName': senderName.trim(),
      'recipientPublicId': recipientId,
      'shareType': shareType,
      'placeName': placeName.trim(),
      'placeId': placeDocumentId.trim(),
      'latitude': latitude,
      'longitude': longitude,
      'durationMinutes': durationMinutes,
      'status': 'pending',
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
      'expiresAt': Timestamp.fromDate(expiresAt),
    });
    return ref.id;
  }

  static Map<String, dynamic> _locationShareMap(
    QueryDocumentSnapshot<Map<String, dynamic>> document,
  ) {
    final data = document.data();
    String? asIso(dynamic value) {
      if (value is Timestamp) return value.toDate().toIso8601String();
      if (value is DateTime) return value.toIso8601String();
      return null;
    }

    return <String, dynamic>{
      'id': document.id,
      ...data,
      'createdAtIso': asIso(data['createdAt']),
      'updatedAtIso': asIso(data['updatedAt']),
      'expiresAtIso': asIso(data['expiresAt']),
      'acceptedAtIso': asIso(data['acceptedAt']),
      'rejectedAtIso': asIso(data['rejectedAt']),
    };
  }

  static Stream<List<Map<String, dynamic>>> locationSharesStream(
    String recipientPublicId,
  ) {
    final id = normalizeSharePublicId(recipientPublicId);
    if (!isReady || id.isEmpty) {
      return Stream<List<Map<String, dynamic>>>.value(
        const <Map<String, dynamic>>[],
      );
    }

    return FirebaseFirestore.instance
        .collection('deda_location_shares')
        .where('recipientPublicId', isEqualTo: id)
        .limit(100)
        .snapshots()
        .map((snapshot) {
      final items = snapshot.docs.map(_locationShareMap).toList();
      items.sort((a, b) {
        final ad = DateTime.tryParse((a['createdAtIso'] ?? '').toString());
        final bd = DateTime.tryParse((b['createdAtIso'] ?? '').toString());
        return (bd ?? DateTime.fromMillisecondsSinceEpoch(0))
            .compareTo(ad ?? DateTime.fromMillisecondsSinceEpoch(0));
      });
      return items;
    });
  }

  static Stream<int> pendingLocationSharesCountStream(
    String recipientPublicId,
  ) {
    return locationSharesStream(recipientPublicId).map((items) {
      final now = DateTime.now();
      var count = 0;
      for (final item in items) {
        final status = (item['status'] ?? 'pending').toString();
        final expires =
            DateTime.tryParse((item['expiresAtIso'] ?? '').toString());
        if (status == 'pending' && expires != null && expires.isAfter(now)) {
          count++;
        }
      }
      return count;
    });
  }

  static Future<void> decideLocationShare({
    required String shareId,
    required bool accept,
  }) async {
    if (!isReady) throw StateError('firebase-not-ready');
    final cleanId = shareId.trim();
    if (cleanId.isEmpty) throw ArgumentError('share-id-required');
    final update = <String, dynamic>{
      'status': accept ? 'accepted' : 'rejected',
      'updatedAt': FieldValue.serverTimestamp(),
      'readAt': FieldValue.serverTimestamp(),
      if (accept) 'acceptedAt': FieldValue.serverTimestamp(),
      if (!accept) 'rejectedAt': FieldValue.serverTimestamp(),
    };
    await FirebaseFirestore.instance
        .collection('deda_location_shares')
        .doc(cleanId)
        .update(update);
  }
}
